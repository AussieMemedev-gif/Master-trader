# Master Trader — Stage 1

A mobile-friendly paper-trading control centre for the autonomous meme-coin trading bot concept.

## What Stage 1 includes
- Simple ON/OFF bot control
- Paper / Assisted / Auto mode selector
- Per-trade presets: $5, $10, $15, $20, $50, $100 + Custom
- Daily profit target and daily max loss
- Safe / Balanced / Aggressive risk presets
- Auto-scale winners toggle
- Mock Hot Meme scanner with 10-agent style scoring
- Paper positions, PNL, partial/full sell controls
- Profit target and daily loss auto-stop safeguards
- Beginner help panel
- Mobile responsive dashboard
- Real-money execution intentionally locked out in Stage 1

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app:app --reload
```
Then open http://127.0.0.1:8000

## Railway
1. Create a new GitHub repository and upload all files in this folder.
2. Connect the repo to Railway.
3. Railway should detect the Procfile automatically.
4. Deploy.
5. Open the generated Railway domain.

## Important
This stage is PAPER TRADING ONLY. Do not add private keys or live-wallet secrets yet.
