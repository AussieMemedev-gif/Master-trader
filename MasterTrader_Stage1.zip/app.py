import asyncio
import random
import time
from datetime import datetime, timezone
from typing import Literal

from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

app = FastAPI(title="Master Trader Stage 1", version="1.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

PRESETS = [5, 10, 15, 20, 50, 100]

TOKENS = [
    ("WICK", "WICK", "Solana"),
    ("PEPEMAX", "PEPEM", "Solana"),
    ("BONKFIRE", "BONKF", "Solana"),
    ("MOONPUG", "MPUG", "Solana"),
    ("FROGBID", "FRB", "Solana"),
    ("BULLBYTE", "BBYTE", "Robinhood Chain"),
    ("CATWAVE", "CWAVE", "Robinhood Chain"),
    ("GIGAWICK", "GWICK", "Solana"),
]

class Settings(BaseModel):
    trade_size: float = Field(default=10, ge=5, le=100000)
    daily_target: float = Field(default=500, ge=1, le=1000000)
    daily_loss_limit: float = Field(default=250, ge=1, le=1000000)
    max_positions: int = Field(default=5, ge=1, le=50)
    risk_mode: Literal["safe", "balanced", "aggressive"] = "balanced"
    mode: Literal["paper", "assisted", "auto"] = "paper"
    profit_protection: bool = True
    auto_scale: Literal["off", "low", "medium", "high"] = "off"

class OpenTradeRequest(BaseModel):
    symbol: str
    amount: float = Field(ge=5, le=100000)

class CloseTradeRequest(BaseModel):
    position_id: int
    percent: float = Field(gt=0, le=100)

state = {
    "bot_on": False,
    "real_money_enabled": False,
    "settings": Settings().model_dump(),
    "starting_balance": 10000.0,
    "cash": 10000.0,
    "realized_pnl": 0.0,
    "positions": [],
    "history": [],
    "scanner": [],
    "last_scan": None,
    "next_position_id": 1,
    "status_message": "Paper engine ready",
    "day_key": datetime.now(timezone.utc).date().isoformat(),
}


def risk_threshold():
    return {"safe": 88, "balanced": 82, "aggressive": 76}[state["settings"]["risk_mode"]]


def make_scan():
    results = []
    for name, symbol, chain in random.sample(TOKENS, k=min(6, len(TOKENS))):
        social = random.randint(55, 99)
        momentum = random.randint(55, 99)
        smart = random.randint(48, 97)
        liquidity = random.randint(55, 96)
        safety = random.randint(55, 99)
        launch = random.randint(50, 96)
        pattern = random.randint(50, 99)
        master = round(
            social * .18 + momentum * .20 + smart * .16 + liquidity * .13 +
            safety * .16 + launch * .08 + pattern * .09
        )
        price = round(random.uniform(0.00002, 0.05), 7)
        results.append({
            "name": name,
            "symbol": symbol,
            "chain": chain,
            "social": social,
            "momentum": momentum,
            "smart_money": smart,
            "liquidity": liquidity,
            "safety": safety,
            "launch": launch,
            "pattern": pattern,
            "master_score": master,
            "price": price,
            "decision": "BUY" if master >= risk_threshold() else "WATCH" if master >= 72 else "REJECT",
            "reason": "Strong acceleration across multiple signals" if master >= risk_threshold() else "Needs more confirmation",
        })
    results.sort(key=lambda x: x["master_score"], reverse=True)
    state["scanner"] = results
    state["last_scan"] = int(time.time())
    return results


def portfolio_value():
    return state["cash"] + sum(p["current_value"] for p in state["positions"])


def unrealized_pnl():
    return sum(p["current_value"] - p["cost_basis"] for p in state["positions"])


def total_daily_pnl():
    return state["realized_pnl"] + unrealized_pnl()


def check_day_rollover():
    today = datetime.now(timezone.utc).date().isoformat()
    if today != state["day_key"]:
        state["day_key"] = today
        state["realized_pnl"] = 0.0
        state["status_message"] = "New UTC trading day started"


def apply_guardrails():
    pnl = total_daily_pnl()
    settings = state["settings"]
    if pnl >= settings["daily_target"]:
        state["bot_on"] = False
        state["status_message"] = f"Daily profit target reached: +${pnl:.2f}. Auto trading stopped."
    elif pnl <= -settings["daily_loss_limit"]:
        state["bot_on"] = False
        state["status_message"] = f"Daily loss limit reached: -${abs(pnl):.2f}. Auto trading stopped."


def open_paper_position(symbol: str, amount: float):
    if amount < 5:
        raise HTTPException(status_code=400, detail="Minimum trade amount is $5")
    if len(state["positions"]) >= state["settings"]["max_positions"]:
        raise HTTPException(status_code=400, detail="Maximum open positions reached")
    if amount > state["cash"]:
        raise HTTPException(status_code=400, detail="Insufficient paper cash")

    token = next((x for x in state["scanner"] if x["symbol"] == symbol), None)
    if not token:
        raise HTTPException(status_code=404, detail="Token not found in current scan")

    price = token["price"]
    qty = amount / price
    position = {
        "id": state["next_position_id"],
        "symbol": symbol,
        "name": token["name"],
        "chain": token["chain"],
        "entry_price": price,
        "current_price": price,
        "qty": qty,
        "cost_basis": amount,
        "current_value": amount,
        "opened_at": int(time.time()),
        "master_score": token["master_score"],
    }
    state["next_position_id"] += 1
    state["cash"] -= amount
    state["positions"].append(position)
    state["status_message"] = f"Paper bought {symbol} for ${amount:.2f}"
    return position


def close_position(position_id: int, percent: float):
    pos = next((p for p in state["positions"] if p["id"] == position_id), None)
    if not pos:
        raise HTTPException(status_code=404, detail="Position not found")
    fraction = percent / 100.0
    sold_value = pos["current_value"] * fraction
    sold_cost = pos["cost_basis"] * fraction
    realized = sold_value - sold_cost
    qty_sold = pos["qty"] * fraction

    state["cash"] += sold_value
    state["realized_pnl"] += realized
    state["history"].append({
        "symbol": pos["symbol"],
        "percent": percent,
        "realized_pnl": realized,
        "sold_value": sold_value,
        "closed_at": int(time.time()),
    })

    if percent >= 99.999:
        state["positions"].remove(pos)
    else:
        pos["qty"] -= qty_sold
        pos["cost_basis"] -= sold_cost
        pos["current_value"] -= sold_value
    state["status_message"] = f"Paper sold {percent:g}% of {pos['symbol']}"
    apply_guardrails()
    return {"realized_pnl": realized}


async def engine_loop():
    while True:
        try:
            check_day_rollover()
            # Update paper prices.
            for pos in list(state["positions"]):
                drift = random.gauss(0.0015, 0.022)
                pos["current_price"] = max(0.0000001, pos["current_price"] * (1 + drift))
                pos["current_value"] = pos["qty"] * pos["current_price"]

                gain_pct = ((pos["current_value"] / pos["cost_basis"]) - 1) * 100
                # Simple Stage 1 risk exits by mode.
                stops = {"safe": -7, "balanced": -10, "aggressive": -15}
                takes = {"safe": 18, "balanced": 28, "aggressive": 40}
                if gain_pct <= stops[state["settings"]["risk_mode"]]:
                    close_position(pos["id"], 100)
                elif gain_pct >= takes[state["settings"]["risk_mode"]]:
                    close_position(pos["id"], 100)

            apply_guardrails()

            # Auto paper trading only.
            if state["bot_on"]:
                make_scan()
                if len(state["positions"]) < state["settings"]["max_positions"]:
                    candidates = [x for x in state["scanner"] if x["decision"] == "BUY" and not any(p["symbol"] == x["symbol"] for p in state["positions"])]
                    if candidates:
                        amount = min(float(state["settings"]["trade_size"]), state["cash"])
                        if amount >= 5:
                            open_paper_position(candidates[0]["symbol"], amount)
        except Exception as exc:
            state["status_message"] = f"Engine warning: {exc}"
        await asyncio.sleep(5)


@app.on_event("startup")
async def startup_event():
    make_scan()
    asyncio.create_task(engine_loop())


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/state")
def get_state():
    check_day_rollover()
    return {
        **state,
        "portfolio_value": portfolio_value(),
        "unrealized_pnl": unrealized_pnl(),
        "daily_pnl": total_daily_pnl(),
        "presets": PRESETS,
        "risk_threshold": risk_threshold(),
    }


@app.post("/api/settings")
def update_settings(settings: Settings):
    state["settings"] = settings.model_dump()
    state["status_message"] = "Settings saved"
    return get_state()


@app.post("/api/bot/{action}")
def set_bot(action: Literal["on", "off"]):
    state["bot_on"] = action == "on"
    state["status_message"] = "Paper auto trader started" if state["bot_on"] else "Trader stopped"
    return get_state()


@app.post("/api/scan")
def scan_market():
    return {"results": make_scan()}


@app.post("/api/trade/open")
def open_trade(req: OpenTradeRequest):
    return open_paper_position(req.symbol, req.amount)


@app.post("/api/trade/close")
def close_trade(req: CloseTradeRequest):
    return close_position(req.position_id, req.percent)


@app.post("/api/reset")
def reset_paper():
    state["bot_on"] = False
    state["cash"] = state["starting_balance"]
    state["realized_pnl"] = 0.0
    state["positions"].clear()
    state["history"].clear()
    state["status_message"] = "Paper account reset"
    make_scan()
    return get_state()


@app.get("/health")
def health():
    return {"ok": True, "stage": 1, "live_trading": False}
