let appState = null;
let selectedTradeSize = 10;
let selectedMode = 'paper';

const $ = id => document.getElementById(id);
const money = n => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(n);

async function api(path, options={}) {
  const res = await fetch(path,{headers:{'Content-Type':'application/json'},...options});
  const data = await res.json();
  if(!res.ok) throw new Error(data.detail || 'Request failed');
  return data;
}

function renderState(s){
  appState=s;
  $('botToggle').textContent=s.bot_on?'ON':'OFF';
  $('botToggle').className='power-btn '+(s.bot_on?'on':'off');
  $('engineStatus').textContent=s.status_message;
  const pnl=s.daily_pnl;
  $('dailyPnl').textContent=(pnl>=0?'+':'')+money(pnl);
  $('dailyPnl').className='pnl-value '+(pnl>=0?'pnl-positive':'pnl-negative');
  $('targetValue').textContent='+'+money(s.settings.daily_target);
  $('lossValue').textContent='-'+money(s.settings.daily_loss_limit);
  $('portfolioValue').textContent=money(s.portfolio_value);
  $('openCount').textContent=`${s.positions.length} / ${s.settings.max_positions}`;
  $('targetProgress').style.width=Math.max(0,Math.min(100,(pnl/s.settings.daily_target)*100))+'%';

  selectedTradeSize=s.settings.trade_size;
  selectedMode=s.settings.mode;
  $('dailyTarget').value=s.settings.daily_target;
  $('dailyLoss').value=s.settings.daily_loss_limit;
  $('maxPositions').value=s.settings.max_positions;
  $('riskMode').value=s.settings.risk_mode;
  $('autoScale').value=s.settings.auto_scale;
  $('profitProtection').checked=s.settings.profit_protection;
  document.querySelectorAll('.mode-card').forEach(b=>b.classList.toggle('active',b.dataset.mode===selectedMode));
  document.querySelectorAll('#presetRow button').forEach(b=>{
    const v=b.dataset.value;
    b.classList.toggle('selected',v!=='custom' && Number(v)===selectedTradeSize);
  });
  renderScanner(s.scanner);
  renderPositions(s.positions);
}

function renderScanner(items){
  $('scannerList').innerHTML=items.map(t=>`
    <div class="token-card">
      <div class="token-top">
        <div><div class="token-name">${t.name} <span style="color:#8fa99c">$${t.symbol}</span></div><span class="chain">${t.chain}</span></div>
        <div style="text-align:right"><div class="score ${t.decision==='BUY'?'buy':'watch'}">${t.master_score}/100</div><span class="decision ${t.decision.toLowerCase()}">${t.decision}</span></div>
      </div>
      <div class="metrics">
        <div class="metric"><span>Social</span><strong>${t.social}</strong></div><div class="metric"><span>Momentum</span><strong>${t.momentum}</strong></div>
        <div class="metric"><span>Smart $</span><strong>${t.smart_money}</strong></div><div class="metric"><span>Liquidity</span><strong>${t.liquidity}</strong></div>
        <div class="metric"><span>Safety</span><strong>${t.safety}</strong></div>
      </div>
      <div class="token-actions"><button class="ape-btn" onclick="ape('${t.symbol}')">APE ${money(selectedTradeSize)}</button></div>
    </div>`).join('');
}

function renderPositions(items){
  if(!items.length){$('positionsList').innerHTML='<div class="empty-state">No open paper trades yet.</div>';return;}
  $('positionsList').innerHTML=items.map(p=>{
    const pnl=p.current_value-p.cost_basis, pct=(pnl/p.cost_basis)*100;
    return `<div class="position-card">
      <div class="position-top"><div><div class="token-name">${p.name} $${p.symbol}</div><span class="chain">${p.chain}</span></div><div class="${pnl>=0?'pnl-positive':'pnl-negative'}"><strong>${pnl>=0?'+':''}${pct.toFixed(2)}%</strong><br><small>${pnl>=0?'+':''}${money(pnl)}</small></div></div>
      <div class="metrics"><div class="metric"><span>Invested</span><strong>${money(p.cost_basis)}</strong></div><div class="metric"><span>Value</span><strong>${money(p.current_value)}</strong></div><div class="metric"><span>AI Score</span><strong>${p.master_score}</strong></div></div>
      <div class="position-actions"><button class="sell-btn" onclick="sell(${p.id},25)">Sell 25%</button><button class="sell-btn" onclick="sell(${p.id},50)">50%</button><button class="sell-btn" onclick="sell(${p.id},75)">75%</button><button class="sell-btn" onclick="sell(${p.id},100)">ALL</button></div>
    </div>`
  }).join('');
}

async function refresh(){try{renderState(await api('/api/state'));}catch(e){$('engineStatus').textContent=e.message;}}

$('botToggle').onclick=async()=>{try{renderState(await api('/api/bot/'+(appState.bot_on?'off':'on'),{method:'POST'}));}catch(e){alert(e.message)}};
$('scanBtn').onclick=async()=>{try{await api('/api/scan',{method:'POST'});refresh();}catch(e){alert(e.message)}};
$('resetBtn').onclick=async()=>{if(confirm('Reset the paper account and erase paper trade history?')) renderState(await api('/api/reset',{method:'POST'}));};
$('helpBtn').onclick=()=>$('helpModal').classList.remove('hidden');
$('closeHelp').onclick=()=>$('helpModal').classList.add('hidden');
$('helpModal').onclick=e=>{if(e.target===$('helpModal')) $('helpModal').classList.add('hidden');};

document.querySelectorAll('.mode-card').forEach(b=>b.onclick=()=>{selectedMode=b.dataset.mode;document.querySelectorAll('.mode-card').forEach(x=>x.classList.toggle('active',x===b));});
document.querySelectorAll('#presetRow button').forEach(b=>b.onclick=()=>{
  document.querySelectorAll('#presetRow button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');
  if(b.dataset.value==='custom'){$('customRow').classList.remove('hidden');selectedTradeSize=Math.max(5,Number($('customTrade').value)||5);} else {$('customRow').classList.add('hidden');selectedTradeSize=Number(b.dataset.value);}
});
$('customTrade').oninput=()=>selectedTradeSize=Math.max(5,Number($('customTrade').value)||5);

$('saveSettings').onclick=async()=>{
  const body={trade_size:selectedTradeSize,daily_target:Number($('dailyTarget').value),daily_loss_limit:Number($('dailyLoss').value),max_positions:Number($('maxPositions').value),risk_mode:$('riskMode').value,mode:selectedMode,profit_protection:$('profitProtection').checked,auto_scale:$('autoScale').value};
  if(body.trade_size<5){alert('Minimum trade amount is $5');return;}
  try{renderState(await api('/api/settings',{method:'POST',body:JSON.stringify(body)}));}catch(e){alert(e.message)}
};

window.ape=async symbol=>{try{await api('/api/trade/open',{method:'POST',body:JSON.stringify({symbol,amount:selectedTradeSize})});refresh();}catch(e){alert(e.message)}};
window.sell=async(id,percent)=>{try{await api('/api/trade/close',{method:'POST',body:JSON.stringify({position_id:id,percent})});refresh();}catch(e){alert(e.message)}};

refresh();setInterval(refresh,2500);
