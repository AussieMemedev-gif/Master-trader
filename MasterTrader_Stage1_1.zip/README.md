# Master Trader — Stage 1.1 Professional Control Centre

Stage 1.1 upgrades the working paper-trading prototype into a premium, mobile-first control centre while preserving the hard lock on real-money execution.

## What changed

- Dedicated **Auto Trade Amount** control: `$5 / $10 / $15 / $20 / $50 / $100 / Custom`.
- Separate manual APE amount.
- Professional responsive dashboard with compact mobile navigation.
- Portfolio of every open paper holding with token logo, invested value, live simulated PNL, AI score and partial/full exits.
- Research shortcuts for **DexScreener**, **Pump.fun** (Solana), **Robinhood** (Robinhood Chain), and **X**.
- User-adjustable daily target, daily loss limit, maximum positions, risk style, minimum score, stop loss, take profit, scan interval and auto-scale setting.
- Assisted mode scans without auto-opening positions.
- Basic paper auto-scale-winner logic.
- Sydney-time daily rollover.
- Local JSON state persistence for development testing.
- Built-in beginner guide.

## Important

This stage still uses simulated token data and simulated prices. External research buttons are convenience links; fictional demo tokens are not real market assets. Live wallet signing and real-money execution remain disabled.

## Local setup

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
uvicorn app:app --host 0.0.0.0 --port 8000
```

Open port 8000. Health check: `/health`.

## Railway

Start command is already provided by `Procfile`:

```text
uvicorn app:app --host 0.0.0.0 --port $PORT
```

Stage 1.1 local JSON persistence is not a production multi-user database. User authentication, isolated portfolios, persistent production storage, and live market/wallet integration belong to later stages.
