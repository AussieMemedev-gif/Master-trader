# Upgrade from Stage 1 to Stage 1.1

Run commands one at a time in the Master-trader Codespace.

1. Stop the running Stage 1 server with `Ctrl+C`.
2. Upload `MasterTrader_Stage1_1.zip` to the GitHub repository and commit the upload.
3. In the Codespace terminal:

```bash
git pull
```

```bash
unzip -o MasterTrader_Stage1_1.zip
```

```bash
source .venv/bin/activate
```

```bash
python --version
```

It should show Python 3.12.x. If `.venv` does not exist, create it with:

```bash
python3.12 -m venv .venv
```

then activate it again.

4. Install/refresh dependencies:

```bash
python -m pip install --upgrade pip setuptools wheel
```

```bash
pip install -r requirements.txt
```

5. Verify the Python app:

```bash
python -m py_compile app.py
```

```bash
python -c "from app import app; print('MASTER TRADER STAGE 1.1 OK')"
```

6. Start it:

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

Open Codespaces Port 8000 and test the professional dashboard.

## Stage 1.1 acceptance test

- Auto trade amount can be set to $5, $10, $15, $20, $50, $100 or Custom.
- Save Settings persists the selected paper settings locally.
- Auto Trader ON opens paper trades using the selected automatic trade amount.
- Assisted mode scans but does not auto-open positions.
- Portfolio lists every open holding with logo, PNL, partial/full sell controls and research links.
- DexScreener and X research buttons appear for demo tokens; Pump.fun appears on Solana demo tokens and Robinhood appears on Robinhood Chain demo tokens.
- Daily target and daily loss controls remain active.
- `/health` returns Stage `1.1` and `live_trading: false`.

## Commit after local verification

Stop the server with `Ctrl+C`, then:

```bash
git add .
```

```bash
git commit -m "Upgrade Master Trader to Stage 1.1 professional control centre"
```

```bash
git push
```

Then redeploy the connected Railway service.
