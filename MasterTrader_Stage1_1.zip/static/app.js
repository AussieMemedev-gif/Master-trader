let appState = null;
let selectedMode = 'paper';
let autoTradeSize = 10;
let manualTradeSize = 10;

const $ = id => document.getElementById(id);
const money = n => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(Number(n)||0);
const num = n => new Intl.NumberFormat('en-US',{maximumFractionDigits:0}).format(Number(n)||0);

async function api(path, options={}) {
  const res = await fetch(path,{headers:{'Content-Type':'application/json'},...options});
  const data = await res.json();
  if(!res.ok) throw new Error(data.detail || 'Request failed');
  return data;
}

function toast(message, bad=false){
  const t=$('toast'); t.textContent=message; t.className='toast '+(bad?'bad':'good');
  clearTimeout(window.__toastTimer); window.__toastTimer=setTimeout(()=>t.classList.add('hidden'),2600);
}

function setPresetButtons(value){
  document.querySelectorAll('#autoPresetRow button').forEach(b=>b.classList.toggle('selected',b.dataset.value!=='custom' && Number(b.dataset.value)===Number(value)));
  const standard=[5,10,15,20,50,100].includes(Number(value));
  $('autoCustomRow').classList.toggle('hidden',standard);
  if(!standard) $('autoCustomTrade').value=value;
}

function renderState(s){
  appState=s;
  selectedMode=s.settings.mode;
  autoTradeSize=Number(s.settings.auto_trade_size);
  manualTradeSize=Number(s.settings.manual_trade_size);

  $('botToggle').classList.toggle('on',s.bot_on);
  $('botToggle').querySelector('b').textContent=s.bot_on?'ON':'OFF';
  $('botStatusText').textContent=s.bot_on?'Auto Trader Running':'Auto Trader Stopped';
  $('engineStatus').textContent=s.status_message;

  const pnl=Number(s.daily_pnl);
  $('dailyPnl').textContent=(pnl>=0?'+':'')+money(pnl);
  $('dailyPnl').className=pnl>=0?'pnl-positive':'pnl-negative';
  $('targetValue').textContent='+'+money(s.settings.daily_target);
  $('portfolioValue').textContent=money(s.portfolio_value);
  $('cashValue').textContent=money(s.cash);
  $('deployedValue').textContent=money(s.deployed_capital);
  $('openCount').textContent=`${s.positions.length} / ${s.settings.max_positions}`;
  $('targetProgress').style.width=Math.max(0,Math.min(100,(pnl/Math.max(1,s.settings.daily_target))*100))+'%';
  $('scannedCount').textContent=num(s.total_scans);
  $('approvedCount').textContent=num(s.approved_today);
  $('autoSizeMetric').textContent=money(autoTradeSize).replace('.00','');
  $('riskMetric').textContent=s.settings.risk_mode[0].toUpperCase()+s.settings.risk_mode.slice(1);
  $('scoreMetric').textContent=`Min score ${s.risk_threshold}`;
  $('autoAmountHeadline').textContent=`${money(autoTradeSize).replace('.00','')} per automatic trade`;

  document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===selectedMode));
  setPresetButtons(autoTradeSize);

  $('autoTradeInput').value=autoTradeSize;
  $('manualTradeInput').value=manualTradeSize;
  $('dailyTarget').value=s.settings.daily_target;
  $('dailyLoss').value=s.settings.daily_loss_limit;
  $('maxPositions').value=s.settings.max_positions;
  $('riskMode').value=s.settings.risk_mode;
  $('minScore').value=s.settings.min_score;
  $('stopLoss').value=s.settings.stop_loss_pct;
  $('takeProfit').value=s.settings.take_profit_pct;
  $('scanInterval').value=String(s.settings.scan_interval_seconds);
  $('autoScale').value=s.settings.auto_scale;
  $('profitProtection').checked=s.settings.profit_protection;

  const upnl=Number(s.unrealized_pnl);
  $('unrealizedPnl').textContent=`${upnl>=0?'+':''}${money(upnl)} unrealized`;
  $('unrealizedPnl').className='portfolio-pnl '+(upnl>=0?'pnl-positive':'pnl-negative');

  renderScanner(s.scanner);
  renderPortfolio(s.positions);
  renderCommander(s.scanner);
}

function researchButtons(links){
  const button=(href,label,cls='')=>href?`<a class="research-link ${cls}" href="${href}" target="_blank" rel="noopener">${label}</a>`:`<span class="research-link disabled ${cls}">${label}</span>`;
  return `${button(links.dexscreener,'DEX','dex')}${button(links.pumpfun,'PF','pump')}${button(links.robinhood,'RH','rh')}${button(links.x,'𝕏','x')}`;
}

function renderScanner(items){
  if(!items?.length){$('scannerList').innerHTML='<div class="empty-state">Scanner warming up…</div>';return;}
  $('scannerList').innerHTML=items.slice(0,6).map((t,i)=>`
    <div class="token-card">
      <div class="token-rank">#${i+1}</div>
      <div class="token-head">
        <div class="token-identity"><div class="token-logo">${t.logo}</div><div><strong>${t.name}</strong><small>$${t.symbol} • ${t.chain}</small></div></div>
        <div class="score-block"><strong>${t.master_score}</strong><small>/100</small><span class="decision ${t.decision.toLowerCase()}">${t.decision}</span></div>
      </div>
      <div class="sparkline"><span style="width:${Math.max(35,t.momentum)}%"></span></div>
      <div class="signal-grid"><span><small>Social</small><b>${t.social}</b></span><span><small>Momentum</small><b>${t.momentum}</b></span><span><small>Smart $</small><b>${t.smart_money}</b></span><span><small>Liquidity</small><b>${t.liquidity}</b></span><span><small>Safety</small><b>${t.safety}</b></span></div>
      <div class="token-bottom"><div class="token-actions"><button onclick="ape('${t.symbol}',5)">APE $5</button><button onclick="ape('${t.symbol}',10)">APE $10</button><button class="auto-buy" onclick="ape('${t.symbol}',manualTradeSize)">APE ${money(manualTradeSize).replace('.00','')}</button></div><div class="research-row">${researchButtons(t.links)}</div></div>
    </div>`).join('');
}

function renderPortfolio(items){
  if(!items?.length){$('positionsList').innerHTML='<div class="empty-state">No open paper positions yet. Turn Auto Trader on or use a manual APE button.</div>';return;}
  $('positionsList').innerHTML=items.map(p=>{
    const pnl=Number(p.current_value)-Number(p.cost_basis); const pct=(pnl/Math.max(.000001,Number(p.cost_basis)))*100;
    return `<article class="holding-card">
      <div class="holding-main">
        <div class="holding-token"><div class="token-logo large">${p.logo||'●'}</div><div><strong>${p.name}</strong><small>$${p.symbol} • ${p.chain}</small><span class="source-chip">${p.source==='auto'?'🤖 Auto':'☝️ Manual'}${p.scale_count?` • Scaled ${p.scale_count}x`:''}</span></div></div>
        <div class="holding-pnl ${pnl>=0?'pnl-positive':'pnl-negative'}"><strong>${pnl>=0?'+':''}${pct.toFixed(2)}%</strong><small>${pnl>=0?'+':''}${money(pnl)}</small></div>
      </div>
      <div class="holding-stats"><span><small>Invested</small><b>${money(p.cost_basis)}</b></span><span><small>Current Value</small><b>${money(p.current_value)}</b></span><span><small>Entry</small><b>${Number(p.entry_price).toPrecision(4)}</b></span><span><small>AI Score</small><b>${p.master_score}/100</b></span></div>
      <div class="holding-footer"><div class="research-row"><span class="research-label">Research</span>${researchButtons(p.links)}</div><div class="sell-actions"><button onclick="sell(${p.id},25)">25%</button><button onclick="sell(${p.id},50)">50%</button><button onclick="sell(${p.id},75)">75%</button><button class="sell-all" onclick="sell(${p.id},100)">Sell All</button></div></div>
    </article>`;
  }).join('');
}

function renderCommander(items){
  const top=items?.[0]; if(!top)return;
  $('commanderScore').textContent=top.master_score;
  $('commanderToken').textContent=`${top.logo} ${top.name} ($${top.symbol})`;
  $('commanderDecision').textContent=top.decision;
  $('commanderDecision').className='decision-pill '+top.decision.toLowerCase();
  const reasons=[
    [`Momentum`,top.momentum, top.momentum>80?'Strong acceleration':'Building'],
    [`Social`,top.social, top.social>80?'High viral velocity':'Moderate attention'],
    [`Smart Money`,top.smart_money, top.smart_money>80?'Wallet accumulation':'Watching wallets'],
    [`Safety`,top.safety, top.safety>85?'Healthy profile':'Extra caution'],
  ];
  $('commanderReasons').innerHTML=reasons.map(r=>`<div><span class="reason-check">✓</span><p><strong>${r[0]} ${r[1]}/100</strong><small>${r[2]}</small></p></div>`).join('');
}

async function refresh(){try{renderState(await api('/api/state'));}catch(e){$('engineStatus').textContent=e.message;}}

$('botToggle').onclick=async()=>{try{renderState(await api('/api/bot/'+(appState.bot_on?'off':'on'),{method:'POST'})); toast(appState.bot_on?'Auto Trader ON':'Auto Trader OFF');}catch(e){toast(e.message,true)}};
$('scanBtn').onclick=async()=>{try{await api('/api/scan',{method:'POST'});await refresh();toast('Fresh paper scan complete');}catch(e){toast(e.message,true)}};
$('resetBtn').onclick=async()=>{if(confirm('Reset the paper account and erase paper trade history?')){try{renderState(await api('/api/reset',{method:'POST'}));toast('Paper account reset');}catch(e){toast(e.message,true)}}};

document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{selectedMode=b.dataset.mode;document.querySelectorAll('[data-mode]').forEach(x=>x.classList.toggle('active',x.dataset.mode===selectedMode));});

document.querySelectorAll('#autoPresetRow button').forEach(b=>b.onclick=()=>{
  if(b.dataset.value==='custom'){$('autoCustomRow').classList.remove('hidden');autoTradeSize=Math.max(5,Number($('autoCustomTrade').value)||5);}else{autoTradeSize=Number(b.dataset.value);$('autoCustomRow').classList.add('hidden');}
  setPresetButtons(autoTradeSize);$('autoTradeInput').value=autoTradeSize;$('autoAmountHeadline').textContent=`${money(autoTradeSize).replace('.00','')} per automatic trade`;
});
$('autoCustomTrade').oninput=()=>{autoTradeSize=Math.max(5,Number($('autoCustomTrade').value)||5);$('autoTradeInput').value=autoTradeSize;$('autoAmountHeadline').textContent=`${money(autoTradeSize).replace('.00','')} per automatic trade`;};
$('autoTradeInput').oninput=()=>{autoTradeSize=Math.max(5,Number($('autoTradeInput').value)||5);setPresetButtons(autoTradeSize);};
$('manualTradeInput').oninput=()=>{manualTradeSize=Math.max(5,Number($('manualTradeInput').value)||5);renderScanner(appState?.scanner||[]);};

$('saveSettings').onclick=async()=>{
  const body={
    auto_trade_size:Math.max(5,Number($('autoTradeInput').value)||autoTradeSize),
    manual_trade_size:Math.max(5,Number($('manualTradeInput').value)||manualTradeSize),
    daily_target:Number($('dailyTarget').value),daily_loss_limit:Number($('dailyLoss').value),max_positions:Number($('maxPositions').value),
    risk_mode:$('riskMode').value,mode:selectedMode,profit_protection:$('profitProtection').checked,auto_scale:$('autoScale').value,
    min_score:Number($('minScore').value),stop_loss_pct:Number($('stopLoss').value),take_profit_pct:Number($('takeProfit').value),scan_interval_seconds:Number($('scanInterval').value)
  };
  try{renderState(await api('/api/settings',{method:'POST',body:JSON.stringify(body)}));toast(`Settings saved • Auto trades ${money(body.auto_trade_size).replace('.00','')}`);}catch(e){toast(e.message,true)}
};

window.ape=async(symbol,amount)=>{try{await api('/api/trade/open',{method:'POST',body:JSON.stringify({symbol,amount:Number(amount)})});await refresh();toast(`Paper bought ${symbol} for ${money(amount)}`);}catch(e){toast(e.message,true)}};
window.sell=async(id,percent)=>{try{await api('/api/trade/close',{method:'POST',body:JSON.stringify({position_id:id,percent})});await refresh();toast(`Paper sell ${percent}% complete`);}catch(e){toast(e.message,true)}};

function openHelp(){$('helpModal').classList.remove('hidden')}
['helpBtn','helpBtn2','mobileHelp'].forEach(id=>$(id)?.addEventListener('click',openHelp));
$('closeHelp').onclick=()=>$('helpModal').classList.add('hidden');
$('helpModal').onclick=e=>{if(e.target===$('helpModal'))$('helpModal').classList.add('hidden')};

document.querySelectorAll('[data-target]').forEach(btn=>btn.addEventListener('click',()=>{
  const el=document.getElementById(btn.dataset.target); if(el)el.scrollIntoView({behavior:'smooth',block:'start'});
  document.querySelectorAll('.mobile-nav button,.nav-btn').forEach(x=>x.classList.remove('active'));btn.classList.add('active');
}));

refresh(); setInterval(refresh,2500);
