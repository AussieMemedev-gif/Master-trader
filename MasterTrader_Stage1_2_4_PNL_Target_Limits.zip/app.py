import asyncio
import json
import random
import time
from datetime import datetime
from pathlib import Path
from typing import Literal
from urllib.parse import quote
from zoneinfo import ZoneInfo

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

APP_VERSION = "1.2.4"
SYDNEY = ZoneInfo("Australia/Sydney")
DATA_DIR = Path("data")
STATE_FILE = DATA_DIR / "state.json"
PRESETS = [5, 10, 15, 20, 50, 100]

app = FastAPI(title="Master Trader", version=APP_VERSION)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

TOKEN_CATALOG = [
    {"name": "WICK", "symbol": "WICK", "chain": "Solana", "launchpad": "Pump.fun", "logo": "🕯️"},
    {"name": "Pepe Max", "symbol": "PEPEM", "chain": "Solana", "launchpad": "Pump.fun", "logo": "🐸"},
    {"name": "Bonk Fire", "symbol": "BONKF", "chain": "Solana", "launchpad": "Pump.fun", "logo": "🐕"},
    {"name": "Moon Pug", "symbol": "MPUG", "chain": "Solana", "launchpad": "Pump.fun", "logo": "🐶"},
    {"name": "Frog Bid", "symbol": "FRB", "chain": "Solana", "launchpad": "Pump.fun", "logo": "🐸"},
    {"name": "Bull Byte", "symbol": "BBYTE", "chain": "Robinhood Chain", "launchpad": "Robinhood Chain", "logo": "🐂"},
    {"name": "Cat Wave", "symbol": "CWAVE", "chain": "Robinhood Chain", "launchpad": "Robinhood Chain", "logo": "🐈"},
    {"name": "Giga Wick", "symbol": "GWICK", "chain": "Solana", "launchpad": "Pump.fun", "logo": "🟩"},
    {"name": "Degen Goat", "symbol": "DGOAT", "chain": "Solana", "launchpad": "Pump.fun", "logo": "🐐"},
    {"name": "Moon Bull", "symbol": "MBULL", "chain": "Robinhood Chain", "launchpad": "Robinhood Chain", "logo": "🚀"},
]


class Settings(BaseModel):
    auto_trade_size: float = Field(default=10, ge=5, le=100000)
    manual_trade_size: float = Field(default=10, ge=5, le=100000)
    daily_target: float = Field(default=500, ge=1, le=1000000)
    daily_loss_limit: float = Field(default=250, ge=1, le=1000000)
    max_positions: int = Field(default=5, ge=1, le=50)
    risk_mode: Literal["safe", "balanced", "aggressive"] = "balanced"
    mode: Literal["paper", "assisted", "auto"] = "paper"
    daily_profit_stop_enabled: bool = False
    daily_profit_stop_limit: float = Field(default=1000, ge=1, le=1000000)
    auto_scale: Literal["off", "low", "medium", "high"] = "off"
    min_score: int = Field(default=82, ge=60, le=99)
    stop_loss_pct: float = Field(default=10, ge=1, le=50)
    take_profit_pct: float = Field(default=28, ge=2, le=500)
    scan_interval_seconds: int = Field(default=8, ge=5, le=60)




class ControlRequest(BaseModel):
    mode: Literal["paper", "assisted", "auto"] | None = None
    auto_trade_size: float | None = Field(default=None, ge=5, le=100000)
    bot_on: bool | None = None


class OpenTradeRequest(BaseModel):
    symbol: str
    amount: float = Field(ge=5, le=100000)


class CloseTradeRequest(BaseModel):
    position_id: int
    percent: float = Field(gt=0, le=100)


def default_state():
    return {
        "bot_on": False,
        "real_money_enabled": False,
        "settings": Settings().model_dump(),
        "starting_balance": 10000.0,
        "cash": 10000.0,
        "realized_pnl": 0.0,
        "positions": [],
        "history": [],
        "scanner": [],
        "last_scan": None,
        "next_position_id": 1,
        "status_message": "Paper engine ready",
        "day_key": datetime.now(SYDNEY).date().isoformat(),
        "total_scans": 0,
        "approved_today": 0,
    }


state = default_state()


def save_state():
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception:
        # Persistence is a convenience in Stage 1.2; engine operation must not depend on disk writes.
        pass


def load_state():
    global state
    try:
        if STATE_FILE.exists():
            loaded = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            baseline = default_state()
            baseline.update(loaded)
            baseline["real_money_enabled"] = False
            baseline["settings"] = Settings(**baseline.get("settings", {})).model_dump()
            state = baseline
    except Exception:
        state = default_state()


def token_links(symbol: str, chain: str):
    q = quote(f"${symbol}")
    dex_q = quote(symbol)
    return {
        "dexscreener": f"https://dexscreener.com/search?q={dex_q}",
        "x": f"https://x.com/search?q={q}&src=typed_query",
        "pumpfun": "https://pump.fun/" if chain == "Solana" else None,
        "robinhood": "https://robinhood.com/" if chain == "Robinhood Chain" else None,
    }


def risk_threshold():
    mode_floor = {"safe": 88, "balanced": 82, "aggressive": 76}[state["settings"]["risk_mode"]]
    return max(mode_floor, int(state["settings"]["min_score"]))


def make_scan():
    results = []
    for token in random.sample(TOKEN_CATALOG, k=min(8, len(TOKEN_CATALOG))):
        social = random.randint(55, 99)
        momentum = random.randint(55, 99)
        smart = random.randint(48, 97)
        liquidity = random.randint(55, 96)
        safety = random.randint(55, 99)
        launch = random.randint(50, 96)
        pattern = random.randint(50, 99)
        master = round(
            social * .18 + momentum * .20 + smart * .16 + liquidity * .13 +
            safety * .16 + launch * .08 + pattern * .09
        )
        price = round(random.uniform(0.00002, 0.05), 7)
        decision = "BUY" if master >= risk_threshold() else "WATCH" if master >= 72 else "REJECT"
        results.append({
            **token,
            "social": social,
            "momentum": momentum,
            "smart_money": smart,
            "liquidity": liquidity,
            "safety": safety,
            "launch": launch,
            "pattern": pattern,
            "master_score": master,
            "price": price,
            "decision": decision,
            "reason": "Strong acceleration across multiple signals" if decision == "BUY" else "Needs more confirmation",
            "links": token_links(token["symbol"], token["chain"]),
            "is_demo": True,
        })
    results.sort(key=lambda x: x["master_score"], reverse=True)
    state["scanner"] = results
    state["last_scan"] = int(time.time())
    state["total_scans"] = int(state.get("total_scans", 0)) + len(results)
    save_state()
    return results


def portfolio_value():
    return state["cash"] + sum(p["current_value"] for p in state["positions"])


def deployed_capital():
    return sum(p["cost_basis"] for p in state["positions"])


def unrealized_pnl():
    return sum(p["current_value"] - p["cost_basis"] for p in state["positions"])


def total_daily_pnl():
    return state["realized_pnl"] + unrealized_pnl()


def check_day_rollover():
    today = datetime.now(SYDNEY).date().isoformat()
    if today != state["day_key"]:
        state["day_key"] = today
        state["realized_pnl"] = 0.0
        state["approved_today"] = 0
        state["status_message"] = "New Sydney trading day started"
        save_state()


def apply_guardrails():
    """Apply hard PNL stops only. The daily target is a guide, never a stop."""
    pnl = total_daily_pnl()
    settings = state["settings"]
    if pnl <= -settings["daily_loss_limit"]:
        state["bot_on"] = False
        state["status_message"] = f"Daily loss limit reached: -${abs(pnl):.2f}. Auto trading stopped."
    elif settings.get("daily_profit_stop_enabled", False) and pnl >= settings.get("daily_profit_stop_limit", 1000):
        state["bot_on"] = False
        state["status_message"] = f"Optional daily profit stop reached: +${pnl:.2f}. Auto trading stopped."


def open_paper_position(symbol: str, amount: float, source: str = "manual"):
    if amount < 5:
        raise HTTPException(status_code=400, detail="Minimum trade amount is $5")
    if len(state["positions"]) >= state["settings"]["max_positions"]:
        raise HTTPException(status_code=400, detail="Maximum open positions reached")
    if amount > state["cash"]:
        raise HTTPException(status_code=400, detail="Insufficient paper cash")

    token = next((x for x in state["scanner"] if x["symbol"] == symbol), None)
    if not token:
        raise HTTPException(status_code=404, detail="Token not found in current scan")

    price = token["price"]
    qty = amount / price
    position = {
        "id": state["next_position_id"],
        "symbol": symbol,
        "name": token["name"],
        "chain": token["chain"],
        "launchpad": token["launchpad"],
        "logo": token["logo"],
        "entry_price": price,
        "current_price": price,
        "qty": qty,
        "cost_basis": amount,
        "current_value": amount,
        "opened_at": int(time.time()),
        "master_score": token["master_score"],
        "safety": token["safety"],
        "social": token["social"],
        "momentum": token["momentum"],
        "source": source,
        "scale_count": 0,
        "last_scale_at": 0,
        "links": token_links(symbol, token["chain"]),
        "is_demo": True,
    }
    state["next_position_id"] += 1
    state["cash"] -= amount
    state["positions"].append(position)
    if source == "auto":
        state["approved_today"] = int(state.get("approved_today", 0)) + 1
    state["status_message"] = f"Paper bought {symbol} for ${amount:.2f} ({source})"
    save_state()
    return position


def scale_position(pos):
    scale_mode = state["settings"]["auto_scale"]
    if scale_mode == "off":
        return False
    config = {
        "low": {"max": 1, "trigger": 12, "fraction": .5},
        "medium": {"max": 2, "trigger": 9, "fraction": .5},
        "high": {"max": 3, "trigger": 7, "fraction": .75},
    }[scale_mode]
    if pos.get("scale_count", 0) >= config["max"]:
        return False
    if time.time() - pos.get("last_scale_at", 0) < 15:
        return False
    gain_pct = ((pos["current_value"] / pos["cost_basis"]) - 1) * 100
    next_trigger = config["trigger"] * (pos.get("scale_count", 0) + 1)
    if gain_pct < next_trigger:
        return False
    add_amount = min(float(state["settings"]["auto_trade_size"]) * config["fraction"], state["cash"])
    if add_amount < 5:
        return False
    add_qty = add_amount / pos["current_price"]
    pos["qty"] += add_qty
    pos["cost_basis"] += add_amount
    pos["current_value"] += add_amount
    pos["scale_count"] = pos.get("scale_count", 0) + 1
    pos["last_scale_at"] = int(time.time())
    state["cash"] -= add_amount
    state["status_message"] = f"Auto scaled {pos['symbol']} by ${add_amount:.2f}"
    save_state()
    return True


def close_position(position_id: int, percent: float):
    pos = next((p for p in state["positions"] if p["id"] == position_id), None)
    if not pos:
        raise HTTPException(status_code=404, detail="Position not found")
    fraction = percent / 100.0
    sold_value = pos["current_value"] * fraction
    sold_cost = pos["cost_basis"] * fraction
    realized = sold_value - sold_cost
    qty_sold = pos["qty"] * fraction

    state["cash"] += sold_value
    state["realized_pnl"] += realized
    state["history"].append({
        "symbol": pos["symbol"],
        "logo": pos.get("logo", "●"),
        "percent": percent,
        "realized_pnl": realized,
        "sold_value": sold_value,
        "closed_at": int(time.time()),
    })

    if percent >= 99.999:
        state["positions"].remove(pos)
    else:
        pos["qty"] -= qty_sold
        pos["cost_basis"] -= sold_cost
        pos["current_value"] -= sold_value
    state["status_message"] = f"Paper sold {percent:g}% of {pos['symbol']}"
    apply_guardrails()
    save_state()
    return {"realized_pnl": realized}


async def engine_loop():
    while True:
        try:
            check_day_rollover()
            settings = state["settings"]

            for pos in list(state["positions"]):
                drift = random.gauss(0.0015, 0.022)
                pos["current_price"] = max(0.0000001, pos["current_price"] * (1 + drift))
                pos["current_value"] = pos["qty"] * pos["current_price"]
                gain_pct = ((pos["current_value"] / pos["cost_basis"]) - 1) * 100

                if gain_pct <= -float(settings["stop_loss_pct"]):
                    close_position(pos["id"], 100)
                elif gain_pct >= float(settings["take_profit_pct"]):
                    close_position(pos["id"], 100)
                else:
                    scale_position(pos)

            apply_guardrails()

            if state["bot_on"]:
                now = int(time.time())
                if not state["last_scan"] or now - state["last_scan"] >= int(settings["scan_interval_seconds"]):
                    make_scan()

                # Only Auto mode may paper-execute automatically. Manual and Assisted never auto-open.
                if settings["mode"] == "auto" and len(state["positions"]) < settings["max_positions"]:
                    candidates = [
                        x for x in state["scanner"]
                        if x["decision"] == "BUY"
                        and x["master_score"] >= risk_threshold()
                        and not any(p["symbol"] == x["symbol"] for p in state["positions"])
                    ]
                    if candidates:
                        amount = min(float(settings["auto_trade_size"]), state["cash"])
                        if amount >= 5:
                            open_paper_position(candidates[0]["symbol"], amount, source="auto")
            save_state()
        except Exception as exc:
            state["status_message"] = f"Engine warning: {exc}"
        await asyncio.sleep(2)


@app.on_event("startup")
async def startup_event():
    load_state()
    make_scan()
    asyncio.create_task(engine_loop())


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/state")
def get_state():
    check_day_rollover()
    return {
        **state,
        "portfolio_value": portfolio_value(),
        "deployed_capital": deployed_capital(),
        "unrealized_pnl": unrealized_pnl(),
        "daily_pnl": total_daily_pnl(),
        "presets": PRESETS,
        "risk_threshold": risk_threshold(),
        "version": APP_VERSION,
        "timezone": "Australia/Sydney",
    }


@app.post("/api/control")
def update_control(req: ControlRequest):
    """Atomically apply the home-screen mode, amount and run-state controls.

    This endpoint intentionally avoids the old multi-request UI sequence that could race
    against the 2.5-second state refresh on mobile Safari.
    """
    settings_data = dict(state.get("settings", Settings().model_dump()))
    if req.mode is not None:
        settings_data["mode"] = req.mode
    if req.auto_trade_size is not None:
        settings_data["auto_trade_size"] = float(req.auto_trade_size)
    settings = Settings(**settings_data)
    state["settings"] = settings.model_dump()

    blocked_reason = None
    if req.bot_on is not None:
        if req.bot_on and settings.mode == "paper":
            state["bot_on"] = False
            blocked_reason = "Manual mode selected. Use the Manual Trade Desk or select AUTO."
        elif req.bot_on:
            pnl = total_daily_pnl()
            if pnl <= -settings.daily_loss_limit:
                state["bot_on"] = False
                blocked_reason = (
                    f"Daily loss limit already reached (-${abs(pnl):.2f}). Reset the paper portfolio "
                    "or increase the loss limit before restarting."
                )
            elif settings.daily_profit_stop_enabled and pnl >= settings.daily_profit_stop_limit:
                state["bot_on"] = False
                blocked_reason = (
                    f"Optional daily profit stop already reached (+${pnl:.2f}). Increase the profit stop, "
                    "turn it off, or reset the paper portfolio before restarting."
                )
            else:
                # The daily target is deliberately not checked here: it is a guide only.
                state["bot_on"] = True
        else:
            state["bot_on"] = False

    if blocked_reason:
        state["status_message"] = blocked_reason
    elif req.bot_on is True:
        if settings.mode == "auto":
            slots = f"{len(state['positions'])}/{settings.max_positions}"
            state["status_message"] = (
                f"AUTO ON • ${settings.auto_trade_size:g}/trade • positions {slots}"
                + (" • waiting for a free slot" if len(state["positions"]) >= settings.max_positions else "")
            )
        else:
            state["status_message"] = "Assisted scanner ON • AI finds, you approve"
    elif req.bot_on is False:
        state["status_message"] = "Trading engine paused"
    elif req.auto_trade_size is not None:
        state["status_message"] = f"Auto trade amount saved: ${settings.auto_trade_size:g} per trade"
    elif req.mode is not None:
        state["status_message"] = f"Trading mode saved: {settings.mode.upper()}"

    save_state()
    result = get_state()
    result["control_blocked"] = blocked_reason
    return result


@app.post("/api/settings")
def update_settings(settings: Settings):
    state["settings"] = settings.model_dump()
    state["status_message"] = f"Settings saved • Auto trade ${settings.auto_trade_size:g}"
    save_state()
    return get_state()


@app.post("/api/bot/{action}")
def set_bot(action: Literal["on", "off"]):
    state["bot_on"] = action == "on"
    state["status_message"] = "Paper auto trader started" if state["bot_on"] else "Trader stopped"
    save_state()
    return get_state()


@app.post("/api/scan")
def scan_market():
    return {"results": make_scan()}


@app.post("/api/trade/open")
def open_trade(req: OpenTradeRequest):
    return open_paper_position(req.symbol, req.amount, source="manual")


@app.post("/api/trade/close")
def close_trade(req: CloseTradeRequest):
    return close_position(req.position_id, req.percent)


@app.post("/api/reset/portfolio")
def reset_portfolio():
    settings = dict(state.get("settings", Settings().model_dump()))
    fresh = default_state()
    fresh["settings"] = settings
    fresh["bot_on"] = False
    state.clear()
    state.update(fresh)
    state["status_message"] = "Paper portfolio reset • bot settings kept"
    make_scan()
    save_state()
    return get_state()


@app.post("/api/reset/settings")
def reset_settings():
    state["settings"] = Settings().model_dump()
    state["bot_on"] = False
    state["status_message"] = "Bot settings reset to defaults"
    save_state()
    return get_state()


@app.post("/api/reset")
def reset_all():
    fresh = default_state()
    state.clear()
    state.update(fresh)
    state["status_message"] = "Paper account and bot settings reset"
    make_scan()
    save_state()
    return get_state()


@app.get("/health")
def health():
    return {"ok": True, "stage": "1.2.4", "version": APP_VERSION, "live_trading": False, "paper_engine": True, "ui": "Bull Run Terminal"}
