# Master Trader — Stage 1.2 Bull Run Terminal

Stage 1.2 replaces the congested Stage 1.1 interface with a complete mobile-first trading terminal inspired by the approved black / gold / green bull dashboard direction.

## What changed

- New **Bull Run Terminal** interface with one clear screen at a time: Home, Scan, Trade, Portfolio, Settings.
- Premium black/navy, chrome-gold and green PNL styling.
- Rotating animated bull hero scenes using lightweight local WebP assets.
- Slot-machine style **Today’s PNL** display and target/loss meters.
- **Manual / Assisted / Auto** modes made explicit and easy to understand.
- Auto trade amount presets: **$5 / $10 / $15 / $20 / $50 / $100 / Custom**.
- Dedicated manual trade desk.
- Hot Meme Scanner with ranked AI scores and one-tap paper APE amounts.
- Portfolio with token logo, PNL, invested/current value, AI score, partial/full sell controls and research shortcuts.
- User-adjustable bot settings: daily target, loss limit, risk style, max positions, score threshold, TP, SL, scan interval and scaling.
- Bull Run event animation: automatically triggers when an open paper position reaches **3x** or **5x**; Settings also includes a safe preview button.
- Stage 1.1 engine retained, with one important correction: **only Auto mode can open automatic positions**. Manual and Assisted never auto-buy.
- Live wallet execution remains hard-locked.

## Trading mode behavior

- **Manual** — user chooses the token and amount. No automatic entries.
- **Assisted** — AI scanner keeps looking for opportunities; user approves trades.
- **Auto** — paper engine can automatically open qualifying positions using the selected auto trade amount and saved guardrails.

## Run locally / Codespaces

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
python -m py_compile app.py
uvicorn app:app --host 0.0.0.0 --port 8000
```

Open Port 8000. Health check: `/health`.

## Important

Stage 1.2 is a **paper-trading development stage**. Token discovery, prices and fills are simulated. Research links are convenience shortcuts. No live wallet signing or real-money execution is enabled.


## Stage 1.2.5
Control Reliability + Wallet Center adds hardened iPhone controls, stale-state protection, and a professional paper wallet display.
