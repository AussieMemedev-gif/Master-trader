# Upgrade Master Trader to Stage 1.2

Run the commands one at a time in the `Master-trader` Codespace.

1. Upload `MasterTrader_Stage1_2_Bull_Run_Terminal.zip` to the GitHub repository and commit the upload.
2. In Codespaces, stop the old server. If Port 8000 is still busy, run:

```bash
pkill -f "uvicorn app:app" || true
```

3. Pull and install the stage:

```bash
git pull
```

```bash
unzip -o MasterTrader_Stage1_2_Bull_Run_Terminal.zip
```

```bash
source .venv/bin/activate
```

```bash
python --version
```

Expected: Python 3.12.x.

```bash
python -m pip install --upgrade pip setuptools wheel
```

```bash
pip install -r requirements.txt
```

4. Verify before starting:

```bash
python -m py_compile app.py
```

```bash
python -c "from app import app; print('MASTER TRADER STAGE 1.2 OK')"
```

5. Start Stage 1.2:

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

6. Open / refresh Codespaces Port 8000.

## Stage 1.2 acceptance test

- Home screen is clean on iPhone with no horizontal overflow.
- Bottom navigation switches between Home / Scan / Trade / Portfolio / Settings instead of stacking everything on one page.
- Manual mode does not auto-open trades.
- Assisted mode scans but does not auto-open trades.
- Auto mode uses the selected $5 / $10 / $15 / $20 / $50 / $100 / Custom amount.
- Manual trade desk can open a paper position.
- Portfolio can partially or fully close positions.
- Settings save and persist locally.
- Bull hero scenes rotate automatically.
- `Preview Bull Run Animation` launches the cinematic event safely.
- If an open paper position reaches 3x or 5x, the Bull Run event launches automatically.
- `/health` reports Stage 1.2 and `live_trading: false`.

## Commit once verified

```bash
git add .
```

```bash
git commit -m "Upgrade Master Trader to Stage 1.2 Bull Run Terminal"
```

```bash
git push
```
