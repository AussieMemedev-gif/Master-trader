# Master Trader Stage 1.2.1

Functional controls patch for the Bull Run Terminal.

## What changed
The Stage 1.2 live refresh could overwrite values while a user was editing the Settings screen. Stage 1.2.1 preserves unsaved edits, makes mode and amount buttons persist correctly, adds explicit custom-amount Apply behaviour, and wires the scanner filter controls.

## Install
1. Stop the running Uvicorn process.
2. Unzip this package over the Stage 1.2 files.
3. Activate the Python 3.12 `.venv`.
4. Run `python -m pip install -r requirements.txt`.
5. Run `python -m py_compile app.py`.
6. Start with `python -m uvicorn app:app --host 0.0.0.0 --port 8000`.

Stage 1.2.1 remains paper-only. Live wallet execution stays locked.
