# Master Trader Stage 1.2.2 — iPhone Control Hotfix

Fixes the iOS/Safari control-layer error that could show `The string did not match the expected pattern.` while the backend remained online.

## Key fixes
- Safari-safe API request handling with timeouts and no-cache behavior.
- Guarded SVG chart rendering so a chart cannot break a control action.
- Explicit button types.
- Separate Reset Bot Settings and Reset Paper Portfolio actions.
- Static asset cache busting.
- Clearer action errors.
- Auto Trader explains when max positions are full.

Paper trading only. Live wallet execution remains locked.
