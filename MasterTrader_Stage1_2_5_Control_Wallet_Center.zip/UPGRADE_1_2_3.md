# Master Trader 1.2.3 — Atomic Auto Control Fix

This hotfix targets the iPhone issue where Auto would not stay ON and the selected trade amount reverted (for example back to $100).

## What changed
- Home controls now use one atomic `/api/control` request instead of multiple settings/bot requests.
- AUTO start applies mode + selected trade amount + ON state together.
- Auto amount preset changes are persisted immediately and confirmed by the backend.
- Background 2.5-second refresh pauses while a control request is in flight, preventing stale state from overwriting taps.
- API calls now use relative paths directly to avoid Safari URL-pattern errors.
- Top status now reads `AUTO ON`, `AI ON`, or `OFF` instead of ambiguous `READY`.
- If profit protection or the loss guard blocks a restart, the dashboard now explains exactly why.
- A full portfolio (5/5 positions) no longer looks like Auto failed: it remains ON and reports that it is waiting for a free slot.
- The upgrade package does NOT contain `data/state.json`, so installing it will not overwrite the user's current settings/portfolio.

## Install
1. Stop Uvicorn.
2. Unzip this package over the current project.
3. Activate `.venv` (Python 3.12).
4. Install requirements.
5. Start with `python -m uvicorn app:app --host 0.0.0.0 --port 8000`.
6. Fully close/reopen the Port 8000 browser tab once so Safari loads `app.js?v=1.2.3`.
