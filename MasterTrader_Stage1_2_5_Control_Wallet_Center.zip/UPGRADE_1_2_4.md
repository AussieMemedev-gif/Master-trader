# Master Trader 1.2.4 — PNL Target & Limits Upgrade

## Key behavior change
The Daily PNL Target (default $500) is now a **goal only**. Reaching or exceeding it never stops Auto Trader. The bot can continue trading after the target is hit.

## Adjustable PNL controls
- Daily PNL Target: editable goal only.
- Daily Loss Stop: editable hard loss guardrail.
- Optional Daily Profit Stop: independent hard profit cap, OFF by default.
- Daily Profit Stop Limit: editable only when the optional profit stop is enabled.

## Install
Stop Uvicorn, unzip over the project, activate Python 3.12 `.venv`, install requirements, and restart with:

```bash
python -m uvicorn app:app --host 0.0.0.0 --port 8000
```

Fully close and reopen the Port 8000 browser tab once so Safari loads `app.js?v=1.2.4`.
