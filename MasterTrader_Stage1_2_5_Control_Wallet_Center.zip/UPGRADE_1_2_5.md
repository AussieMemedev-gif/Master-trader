# Master Trader Stage 1.2.5 — Control Reliability + Wallet Center

## What changed
- Rebuilt browser control bindings around event delegation so buttons survive dynamic re-renders on iPhone Safari.
- Background refresh pauses while controls are being edited or saved.
- Server responses use a revision number so stale refreshes cannot overwrite a newer user choice.
- Auto Trade amount persists immediately when a preset is tapped.
- Manual, Assisted and Auto modes persist through one atomic control API.
- Start/Pause Auto uses the selected mode and auto amount in the same request.
- Settings Save, Reset Settings, Reset Portfolio, Manual Buy, scanner APE and Portfolio Sell controls are all wired through explicit request handlers.
- Added a Wallet Center displaying wallet ID, paper connection status, network, settlement asset, available cash, total value, deployed capital, realized PNL, unrealized PNL and open positions.
- Added Copy Wallet ID with an iPhone-safe fallback.
- Live wallet keys remain disabled. Never enter a seed phrase or private key into this paper build.

## Verification sequence
1. Select AUTO.
2. Tap $50. Confirm the control summary says AUTO SIZE $50.
3. Tap START AUTO TRADING. Confirm AUTO ON remains visible.
4. Open Settings, change Daily PNL Target and Daily Loss Stop, then SAVE CHANGES.
5. Return Home and confirm those values remain.
6. Open Trade, choose a token and manually buy $5.
7. Open Portfolio and sell 25%, then Sell All.
8. Use RESET BOT SETTINGS and confirm configuration defaults return without deleting the wallet card.
