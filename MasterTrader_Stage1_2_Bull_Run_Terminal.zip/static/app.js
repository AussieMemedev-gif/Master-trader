let appState=null;
let selectedMode='paper';
let autoTradeSize=10;
let chartSeries=[10000,10000,10000,10000,10000,10000,10000,10000];
let lastBullKey='';
let sceneIndex=0;

const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2}).format(Number(n)||0);
const shortMoney=n=>money(n).replace('.00','');
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));

async function api(path,options={}){
  const res=await fetch(path,{headers:{'Content-Type':'application/json'},...options});
  const data=await res.json();
  if(!res.ok) throw new Error(data.detail||'Request failed');
  return data;
}
function toast(msg,bad=false){const t=$('toast');t.textContent=msg;t.className='toast '+(bad?'bad':'good');clearTimeout(window.__tt);window.__tt=setTimeout(()=>t.classList.add('hidden'),2300)}

function go(page){
  document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.dataset.page===page));
  document.querySelectorAll('[data-nav]').forEach(b=>b.classList.toggle('active',b.dataset.nav===page));
  window.scrollTo({top:0,behavior:'smooth'});
}
document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>go(b.dataset.nav));
document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>go(b.dataset.go));

function rotateBull(){const scenes=[...document.querySelectorAll('.bull-scene')];if(!scenes.length)return;scenes.forEach((s,i)=>s.classList.toggle('active',i===sceneIndex));sceneIndex=(sceneIndex+1)%scenes.length}
rotateBull();setInterval(rotateBull,7000);

function setPresetButtons(value){
  document.querySelectorAll('#autoPresetRow button').forEach(b=>b.classList.toggle('selected',b.dataset.value!=='custom'&&Number(b.dataset.value)===Number(value)));
  const standard=[5,10,15,20,50,100].includes(Number(value));
  $('autoCustomRow').classList.toggle('hidden',standard);
  if(!standard)$('autoCustomTrade').value=value;
}
function currentSettings(){
  const s=appState?.settings||{};
  return {
    auto_trade_size:Math.max(5,Number($('autoTradeInput').value)||autoTradeSize),
    manual_trade_size:Math.max(5,Number($('manualTradeInput').value)||s.manual_trade_size||10),
    daily_target:Math.max(1,Number($('dailyTarget').value)||500),
    daily_loss_limit:Math.max(1,Number($('dailyLoss').value)||250),
    max_positions:clamp(Number($('maxPositions').value)||5,1,50),
    risk_mode:$('riskMode').value||'balanced',mode:selectedMode,profit_protection:$('profitProtection').checked,
    auto_scale:$('autoScale').value||'off',min_score:clamp(Number($('minScore').value)||82,60,99),
    stop_loss_pct:clamp(Number($('stopLoss').value)||10,1,50),take_profit_pct:clamp(Number($('takeProfit').value)||28,2,500),
    scan_interval_seconds:Number($('scanInterval').value)||8
  };
}
async function persistSettings(silent=false){
  try{const s=await api('/api/settings',{method:'POST',body:JSON.stringify(currentSettings())});renderState(s);if(!silent)toast('Settings saved');return s}catch(e){toast(e.message,true);throw e}
}

function updateModeUI(){
  document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b.dataset.mode===selectedMode));
  const names={paper:'MANUAL',assisted:'ASSISTED',auto:'AUTO'};
  $('modeStatus').textContent=`${names[selectedMode]} • PAPER`;
  $('tradeModeReadout').textContent=names[selectedMode];
  const cta=$('botToggle');
  cta.classList.toggle('on',selectedMode!=='paper'&&Boolean(appState?.bot_on));
  if(selectedMode==='paper')cta.querySelector('b').textContent='OPEN MANUAL TRADE DESK';
  else if(selectedMode==='assisted')cta.querySelector('b').textContent=appState?.bot_on?'PAUSE AI SCANNER':'START AI SCANNER';
  else cta.querySelector('b').textContent=appState?.bot_on?'PAUSE AUTO TRADING':'START AUTO TRADING';
  $('autoAmountPanel').style.opacity=selectedMode==='auto'?'1':'.62';
}

document.querySelectorAll('[data-mode]').forEach(b=>b.onclick=async()=>{
  selectedMode=b.dataset.mode;updateModeUI();
  try{await persistSettings(true)}catch{}
});

document.querySelectorAll('#autoPresetRow button').forEach(b=>b.onclick=()=>{
  if(b.dataset.value==='custom'){$('autoCustomRow').classList.remove('hidden');autoTradeSize=Math.max(5,Number($('autoCustomTrade').value)||5)}else{autoTradeSize=Number(b.dataset.value);$('autoCustomRow').classList.add('hidden')}
  setPresetButtons(autoTradeSize);$('autoTradeInput').value=autoTradeSize;$('autoAmountHeadline').textContent=`${shortMoney(autoTradeSize)} per automatic trade`;
});
$('autoCustomTrade').oninput=()=>{autoTradeSize=Math.max(5,Number($('autoCustomTrade').value)||5);$('autoTradeInput').value=autoTradeSize;$('autoAmountHeadline').textContent=`${shortMoney(autoTradeSize)} per automatic trade`};
$('autoTradeInput').oninput=()=>{autoTradeSize=Math.max(5,Number($('autoTradeInput').value)||5);setPresetButtons(autoTradeSize);$('autoAmountHeadline').textContent=`${shortMoney(autoTradeSize)} per automatic trade`};

document.querySelectorAll('#manualPresets button').forEach(b=>b.onclick=()=>{$('manualTradeInput').value=Number(b.dataset.value)});

$('botToggle').onclick=async()=>{
  try{
    if(selectedMode==='paper'){go('trade');return}
    await persistSettings(true);
    const turnOn=!appState.bot_on;
    renderState(await api('/api/bot/'+(turnOn?'on':'off'),{method:'POST'}));
    toast(turnOn?(selectedMode==='auto'?'Auto Trader started':'AI scanner started'):'Trading engine paused');
  }catch(e){toast(e.message,true)}
};

$('scanBtn').onclick=async()=>{try{await api('/api/scan',{method:'POST'});await refresh();toast('Fresh scan complete')}catch(e){toast(e.message,true)}};
$('saveSettings').onclick=()=>persistSettings(false);
$('resetBtn').onclick=async()=>{if(!confirm('Reset the paper account and paper trade history?'))return;try{renderState(await api('/api/reset',{method:'POST'}));toast('Paper account reset')}catch(e){toast(e.message,true)}};

$('manualBuy').onclick=async()=>{const symbol=$('manualToken').value;const amount=Math.max(5,Number($('manualTradeInput').value)||5);if(!symbol)return toast('Select a token first',true);try{await api('/api/trade/open',{method:'POST',body:JSON.stringify({symbol,amount})});await refresh();toast(`Paper bought ${symbol} for ${money(amount)}`);go('portfolio')}catch(e){toast(e.message,true)}};
window.ape=async(symbol,amount)=>{try{await api('/api/trade/open',{method:'POST',body:JSON.stringify({symbol,amount:Number(amount)})});await refresh();toast(`Paper bought ${symbol} for ${money(amount)}`)}catch(e){toast(e.message,true)}};
window.sell=async(id,percent)=>{try{await api('/api/trade/close',{method:'POST',body:JSON.stringify({position_id:id,percent})});await refresh();toast(`Paper sell ${percent}% complete`)}catch(e){toast(e.message,true)}};

function researchButtons(links={}){const a=(href,label)=>href?`<a class="research-link" href="${href}" target="_blank" rel="noopener">${label}</a>`:'';return a(links.dexscreener,'DEX')+a(links.pumpfun,'PF')+a(links.robinhood,'RH')+a(links.x,'𝕏')}
function renderScanner(items=[]){
  const root=$('scannerList');
  if(!items.length){root.innerHTML='<div class="token-card">Scanner warming up…</div>';return}
  root.innerHTML=items.slice(0,8).map((t,i)=>`<article class="token-card">
    <div class="token-top"><div class="rank">#${i+1}</div><div class="token-logo">${t.logo}</div><div class="token-copy"><strong>${t.name} <span class="decision ${t.decision.toLowerCase()}">${t.decision}</span></strong><small>$${t.symbol} • ${t.chain} • ${t.launchpad}</small></div><div class="ai-score"><b>${t.master_score}</b><small>AI SCORE</small></div></div>
    <div class="score-bar"><i style="width:${t.master_score}%"></i></div>
    <div class="token-badges"><span class="${t.decision==='BUY'?'buy':''}">Momentum ${t.momentum}</span><span>Social ${t.social}</span><span>Smart $ ${t.smart_money}</span><span>Safety ${t.safety}</span></div>
    <div class="token-actions"><button onclick="ape('${t.symbol}',5)">APE $5</button><button onclick="ape('${t.symbol}',10)">APE $10</button><button class="ape" onclick="ape('${t.symbol}',${Math.max(5,Number(appState?.settings?.manual_trade_size)||10)})">APE ${shortMoney(appState?.settings?.manual_trade_size||10)}</button>${t.links?.dexscreener?`<a class="research-link" href="${t.links.dexscreener}" target="_blank" rel="noopener">DEX</a>`:''}</div>
  </article>`).join('');
  $('manualToken').innerHTML=items.map(t=>`<option value="${t.symbol}">${t.logo} ${t.name} ($${t.symbol}) — AI ${t.master_score}</option>`).join('');
}
function renderPortfolio(items=[]){
  const root=$('positionsList');
  if(!items.length){root.innerHTML='<article class="holding-card"><div class="holding-info"><strong>No open paper positions</strong><small>Use Manual Trade or start Auto mode.</small></div></article>';return}
  root.innerHTML=items.map(p=>{const pnl=Number(p.current_value)-Number(p.cost_basis);const pct=pnl/Math.max(.000001,Number(p.cost_basis))*100;return `<article class="holding-card">
    <div class="holding-head"><div class="token-logo">${p.logo||'●'}</div><div class="holding-info"><strong>${p.name}</strong><small>$${p.symbol} • ${p.chain} • ${p.source==='auto'?'AUTO':'MANUAL'}</small></div><div class="holding-pnl ${pnl>=0?'positive':'negative'}"><b>${pnl>=0?'+':''}${pct.toFixed(1)}%</b><small>${pnl>=0?'+':''}${money(pnl)}</small></div></div>
    <div class="holding-meta"><span>INVESTED<b>${money(p.cost_basis)}</b></span><span>VALUE<b>${money(p.current_value)}</b></span><span>AI SCORE<b>${p.master_score}/100</b></span></div>
    <div class="holding-footer"><div class="research-links">${researchButtons(p.links)}</div><div class="sell-links"><button onclick="sell(${p.id},25)">25%</button><button onclick="sell(${p.id},50)">50%</button><button onclick="sell(${p.id},100)">SELL ALL</button></div></div>
  </article>`}).join('')
}
function renderAI(top){
  if(!top)return;
  $('quickToken').textContent=`${top.logo} ${top.name} ($${top.symbol})`;$('quickScore').textContent=top.master_score;$('homeScore').textContent=top.master_score;
  $('quickReasons').innerHTML=`<span>Momentum ${top.momentum}</span><span>Social ${top.social}</span><span>Smart Money ${top.smart_money}</span><span>Safety ${top.safety}</span>`;
  $('aiWhyToken').textContent=`${top.logo} ${top.name} • ${top.decision}`;
  const reasons=[['Momentum',top.momentum,top.momentum>80?'Strong acceleration':'Building momentum'],['Social',top.social,top.social>80?'High viral velocity':'Moderate attention'],['Smart Money',top.smart_money,top.smart_money>80?'Wallet accumulation':'Wallets still confirming'],['Safety',top.safety,top.safety>85?'Healthy profile':'Extra caution required'],['Liquidity',top.liquidity,top.liquidity>80?'Execution depth looks healthy':'Liquidity needs monitoring']];
  $('aiWhyReasons').innerHTML=reasons.map(r=>`<div><i>✓</i><span><b>${r[0]} ${r[1]}/100</b><small>${r[2]}</small></span></div>`).join('')
}
function updateChart(value){
  const last=chartSeries[chartSeries.length-1]||value;if(Math.abs(value-last)>.01)chartSeries.push(value);else chartSeries.push(last+(Math.random()-.45)*Math.max(1,last*.0018));if(chartSeries.length>24)chartSeries.shift();
  const min=Math.min(...chartSeries),max=Math.max(...chartSeries),span=Math.max(1,max-min);const pts=chartSeries.map((v,i)=>[i/(chartSeries.length-1)*360,110-((v-min)/span)*88]);
  const d=pts.map((p,i)=>`${i?'L':'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');$('chartLine').setAttribute('d',d);$('chartArea').setAttribute('d',`${d} L360,120 L0,120 Z`)
}
function maybeBullEvent(s){
  let best=null;for(const p of s.positions||[]){const mult=Number(p.current_value)/Math.max(.000001,Number(p.cost_basis));if(!best||mult>best.mult)best={p,mult}}
  if(!best||best.mult<3)return;const level=best.mult>=5?5:3;const key=`${best.p.id}:${level}`;if(key===lastBullKey)return;lastBullKey=key;showBullEvent(level,best.p.symbol,best.mult)
}
function showBullEvent(level=5,token='MASTER TRADER',mult=level){
  $('eventEyebrow').textContent=level>=5?'BULL RUN JACKPOT':'BULL RUN MODE';$('eventTitle').textContent=level>=5?'MEGA WIN':'BULL RUN';$('eventValue').textContent=`${mult.toFixed(1)}X TRADE`;$('eventToken').textContent=`$${token} • MOMENTUM UNLEASHED`;$('bullEvent').classList.add('show');$('bullEvent').setAttribute('aria-hidden','false')
}
$('previewBull').onclick=()=>showBullEvent(5,'PREVIEW',5);$('closeBullEvent').onclick=()=>{$('bullEvent').classList.remove('show');$('bullEvent').setAttribute('aria-hidden','true')};

function renderState(s){
  appState=s;selectedMode=s.settings.mode;autoTradeSize=Number(s.settings.auto_trade_size);
  $('enginePill').classList.toggle('on',s.bot_on);$('engineShort').textContent=s.bot_on?'ONLINE':'READY';$('botDot').classList.toggle('on',s.bot_on);$('botStatusText').textContent=s.bot_on?(selectedMode==='auto'?'AUTO TRADER LIVE':'AI SCANNER LIVE'):'AUTO TRADER OFF';$('engineStatus').textContent=s.status_message;
  const pnl=Number(s.daily_pnl),target=Number(s.settings.daily_target),loss=Number(s.settings.daily_loss_limit);$('dailyPnl').textContent=(pnl>=0?'+':'')+money(pnl);$('dailyPnl').className=pnl<0?'negative':'';$('targetValue').textContent=money(target);$('lossValue').textContent='-'+money(loss);$('targetProgress').style.width=clamp((Math.max(0,pnl)/target)*100,0,100)+'%';$('lossProgress').style.width=clamp((Math.max(0,-pnl)/loss)*100,0,100)+'%';$('pnlSub').textContent=pnl>=target?'TARGET ACHIEVED • PROFIT PROTECTION':pnl>0?'GREEN DAY • PAPER PERFORMANCE':'PAPER PERFORMANCE';
  $('portfolioValue').textContent=money(s.portfolio_value);$('portfolioValue2').textContent=money(s.portfolio_value);$('cashValue').textContent=money(s.cash);$('cashValue2').textContent=money(s.cash);$('deployedValue').textContent=money(s.deployed_capital);$('openCount').textContent=`${s.positions.length} / ${s.settings.max_positions}`;$('positionCount2').textContent=s.positions.length;$('historyCount').textContent=(s.history||[]).length;
  const up=Number(s.unrealized_pnl);$('unrealizedPnl').textContent=(up>=0?'+':'')+money(up);$('unrealizedPnl').className=up>=0?'positive':'negative';$('scannedCount').textContent=s.total_scans||0;$('approvedCount').textContent=s.approved_today||0;$('scoreMetric').textContent=s.risk_threshold;$('riskMetric').textContent=s.settings.risk_mode[0].toUpperCase()+s.settings.risk_mode.slice(1);
  setPresetButtons(autoTradeSize);$('autoAmountHeadline').textContent=`${shortMoney(autoTradeSize)} per automatic trade`;$('autoTradeInput').value=autoTradeSize;$('manualTradeInput').value=s.settings.manual_trade_size;$('dailyTarget').value=s.settings.daily_target;$('dailyLoss').value=s.settings.daily_loss_limit;$('riskMode').value=s.settings.risk_mode;$('maxPositions').value=s.settings.max_positions;$('minScore').value=s.settings.min_score;$('takeProfit').value=s.settings.take_profit_pct;$('stopLoss').value=s.settings.stop_loss_pct;$('scanInterval').value=String(s.settings.scan_interval_seconds);$('autoScale').value=s.settings.auto_scale;$('profitProtection').checked=s.settings.profit_protection;
  renderScanner(s.scanner||[]);renderPortfolio(s.positions||[]);renderAI((s.scanner||[])[0]);updateModeUI();updateChart(Number(s.portfolio_value));maybeBullEvent(s)
}
async function refresh(){try{renderState(await api('/api/state'))}catch(e){$('engineStatus').textContent=e.message}}

$('homeHelp').onclick=()=>$('helpModal').classList.remove('hidden');$('menuBtn').onclick=()=>$('helpModal').classList.remove('hidden');$('closeHelp').onclick=()=>$('helpModal').classList.add('hidden');$('helpModal').onclick=e=>{if(e.target===$('helpModal'))$('helpModal').classList.add('hidden')};
refresh();setInterval(refresh,2500);
