# Master Trader — Stage 1.3 Live Intelligence Engine

Stage 1.3 removes the simulated token generator. Market discovery, prices, liquidity, transaction counts, volume, pair age and chart data now come from live Solana market providers. **Execution remains paper-only.**

## Live data stack

- **DEX Screener** — live Solana token/pair discovery and market snapshots.
- **GeckoTerminal** — independent trending/new-pool discovery, OHLCV candles and recent on-chain pool trades.
- **Pump.fun** — best-effort server-side enrichment for leading Pump.fun candidates (bonding/graduated status where the public frontend endpoint responds).
- **Helius** — optional RPC health connector when `HELIUS_API_KEY` is configured. Stage 1.3 does not yet use Helius for smart-wallet scoring.
- **X** — not connected in Stage 1.3. Community scoring uses live market/community metadata, not invented X virality.

## Professional systems added

- Live Solana scanner; no fake fallback market data.
- 1m / 5m / 15m / 1h on-chain OHLCV chart panel.
- Recent on-chain trade feed for the selected pool.
- Contract-address / token search.
- Market data health gate: new Auto entries fail closed if live data becomes stale.
- Real liquidity, volume, buy/sell flow, pair age, market cap/FDV and price-change scoring.
- Entry-quality score to avoid blindly chasing vertical pumps.
- Liquidity/sellability/valuation safety heuristics with explicit risk reasons.
- User-adjustable minimum liquidity, portfolio heat and Auto entry cooldown.
- Live-market paper fills with modeled slippage and fees.
- Live mark-to-market PNL from real market prices.
- Strategy journal with win rate, profit factor, expectancy, average win/loss, MFE/MAE and exit reasons.
- Daily PNL target remains a **goal only**; it does not stop Auto Trader.
- Daily loss stop remains an adjustable hard guardrail.

## Important safety boundary

Stage 1.3 does not sign transactions, hold a private key, request a seed phrase or spend real funds. This is intentional. Validate the strategy against a meaningful sample of live-market paper trades before adding live execution.

Public read APIs can be delayed/cached and are not exchange-grade tick feeds. For lower latency and deeper on-chain wallet intelligence, the next infrastructure step is a dedicated Helius streaming/RPC integration.

## Install

See `UPGRADE_1_3.md`.
