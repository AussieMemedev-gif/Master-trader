# Upgrade to Master Trader Stage 1.3

Use a fresh Bash terminal in Codespaces and run **one line at a time**:

```bash
source .venv/bin/activate
```

```bash
unzip -o MasterTrader_Stage1_3_Live_Intelligence_Engine.zip
```

```bash
python -m pip install -r requirements.txt
```

```bash
python -m py_compile app.py
```

```bash
pkill -f "uvicorn app:app" || true
```

```bash
python -m uvicorn app:app --host 0.0.0.0 --port 8000
```

Then close the old Port 8000 browser tab and reopen Port 8000.

## First acceptance test

1. Home shows `LIVE DATA HEALTH`.
2. DEX Screener should become `LIVE`; GeckoTerminal should become `LIVE` once chart/discovery calls succeed.
3. Scanner cards show real Solana token addresses, prices, liquidity, volume and buy/sell flow.
4. Open a token's **LIVE CHART** and switch 1M / 5M / 15M / 1H.
5. Keep execution in Manual or Assisted first and make a small $5 paper trade.
6. Verify the position PNL changes only when the live market price changes.
7. Test Auto only after the live-data gate reports healthy.

If market providers are unavailable, Master Trader deliberately shows degraded/stale status and pauses new Auto entries instead of inventing prices.
