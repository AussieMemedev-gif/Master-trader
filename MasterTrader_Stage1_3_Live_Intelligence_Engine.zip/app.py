import asyncio
import concurrent.futures
import json
import math
import os
import secrets
import time
from datetime import datetime
from pathlib import Path
from typing import Literal
from urllib.parse import quote
from zoneinfo import ZoneInfo

import httpx
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

APP_VERSION = "1.3.0"
STRATEGY_VERSION = "LIVE-1.3A"
SYDNEY = ZoneInfo("Australia/Sydney")
DATA_DIR = Path("data")
STATE_FILE = DATA_DIR / "state.json"
PRESETS = [5, 10, 15, 20, 50, 100]
DEX_BASE = "https://api.dexscreener.com"
GECKO_BASE = "https://api.geckoterminal.com/api/v2"
NETWORK = "solana"
USER_AGENT = "MasterTrader/1.3 (+paper-trading; live-market-data)"

app = FastAPI(title="Master Trader", version=APP_VERSION)
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


class Settings(BaseModel):
    auto_trade_size: float = Field(default=10, ge=5, le=100000)
    manual_trade_size: float = Field(default=10, ge=5, le=100000)
    daily_target: float = Field(default=500, ge=1, le=1000000)
    daily_loss_limit: float = Field(default=250, ge=1, le=1000000)
    max_positions: int = Field(default=5, ge=1, le=50)
    risk_mode: Literal["safe", "balanced", "aggressive"] = "balanced"
    mode: Literal["paper", "assisted", "auto"] = "paper"
    daily_profit_stop_enabled: bool = False
    daily_profit_stop_limit: float = Field(default=1000, ge=1, le=1000000)
    auto_scale: Literal["off", "low", "medium", "high"] = "off"
    min_score: int = Field(default=82, ge=60, le=99)
    stop_loss_pct: float = Field(default=15, ge=1, le=80)
    take_profit_pct: float = Field(default=60, ge=2, le=1000)
    scan_interval_seconds: int = Field(default=30, ge=15, le=300)
    min_liquidity_usd: float = Field(default=10000, ge=1000, le=10000000)
    max_portfolio_heat_pct: float = Field(default=30, ge=5, le=100)
    entry_cooldown_seconds: int = Field(default=30, ge=10, le=1800)


class ControlRequest(BaseModel):
    mode: Literal["paper", "assisted", "auto"] | None = None
    auto_trade_size: float | None = Field(default=None, ge=5, le=100000)
    bot_on: bool | None = None


class OpenTradeRequest(BaseModel):
    symbol: str | None = None
    token_address: str | None = None
    amount: float = Field(ge=5, le=100000)


class CloseTradeRequest(BaseModel):
    position_id: int
    percent: float = Field(gt=0, le=100)


def default_market_state():
    return {
        "mode": "LIVE",
        "network": "Solana",
        "last_good_market_at": 0,
        "last_scan_at": 0,
        "last_position_price_at": 0,
        "auto_paused_reason": "Waiting for first live market scan",
        "providers": {
            "dexscreener": {"status": "starting", "last_ok": 0, "error": None},
            "geckoterminal": {"status": "starting", "last_ok": 0, "error": None},
            "pumpfun": {"status": "optional", "last_ok": 0, "error": None},
            "helius": {"status": "optional", "configured": bool(os.getenv("HELIUS_API_KEY")), "note": "RPC health only in Stage 1.3"},
            "x": {"status": "not_connected", "configured": False, "note": "X social velocity connector not enabled in Stage 1.3"},
        },
    }


def default_state():
    return {
        "app_version": APP_VERSION,
        "strategy_version": STRATEGY_VERSION,
        "bot_on": False,
        "real_money_enabled": False,
        "paper_wallet_id": "MT-PAPER-" + secrets.token_hex(4).upper(),
        "revision": 0,
        "settings": Settings().model_dump(),
        "starting_balance": 10000.0,
        "cash": 10000.0,
        "realized_pnl": 0.0,
        "positions": [],
        "history": [],
        "scanner": [],
        "watchlist": [],
        "last_scan": None,
        "next_position_id": 1,
        "status_message": "Connecting to live Solana market feeds…",
        "day_key": datetime.now(SYDNEY).date().isoformat(),
        "total_scans": 0,
        "approved_today": 0,
        "last_auto_trade_at": 0,
        "market": default_market_state(),
    }


state = default_state()
_chart_cache: dict[tuple[str, str], tuple[float, dict]] = {}
_trades_cache: dict[str, tuple[float, dict]] = {}


def save_state():
    state["revision"] = int(state.get("revision", 0)) + 1
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        STATE_FILE.write_text(json.dumps(state, indent=2), encoding="utf-8")
    except Exception:
        pass


def migrate_loaded_state(loaded: dict) -> dict:
    old_version = str((loaded or {}).get("app_version") or "")
    baseline = default_state()
    baseline.update(loaded or {})
    baseline["app_version"] = APP_VERSION
    if not old_version.startswith("1.3"):
        baseline["last_scan"] = None
        baseline["scanner"] = []
        baseline["market"] = default_market_state()
    baseline["real_money_enabled"] = False
    raw_settings = dict(baseline.get("settings") or {})
    if int(raw_settings.get("scan_interval_seconds", 30) or 30) < 15:
        raw_settings["scan_interval_seconds"] = 30
    baseline["settings"] = Settings(**raw_settings).model_dump()
    baseline["market"] = {**default_market_state(), **(baseline.get("market") or {})}
    baseline["market"]["providers"] = {
        **default_market_state()["providers"],
        **((baseline.get("market") or {}).get("providers") or {}),
    }
    # Simulated Stage 1.2 positions must never masquerade as live-market positions.
    legacy_positions = [p for p in baseline.get("positions", []) if not p.get("token_address")]
    if legacy_positions:
        baseline["cash"] = float(baseline.get("starting_balance", 10000.0))
        baseline["realized_pnl"] = 0.0
        baseline["positions"] = []
        baseline["history"] = []
        baseline["status_message"] = "Stage 1.3 cleared old simulated positions; live-market paper wallet ready"
    baseline["scanner"] = [t for t in baseline.get("scanner", []) if t.get("token_address") and t.get("is_live")]
    return baseline


def load_state():
    global state
    try:
        if STATE_FILE.exists():
            state = migrate_loaded_state(json.loads(STATE_FILE.read_text(encoding="utf-8")))
        else:
            state = default_state()
    except Exception:
        state = default_state()


def clamp(value, low=0.0, high=100.0):
    return max(low, min(high, float(value)))


def fnum(value, default=0.0):
    try:
        if value is None:
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def inum(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def age_minutes(created_ms):
    if not created_ms:
        return None
    return max(0.0, (time.time() - (float(created_ms) / 1000.0)) / 60.0)


def provider_ok(name: str):
    p = state["market"]["providers"].setdefault(name, {})
    p["status"] = "live"
    p["last_ok"] = int(time.time())
    p["error"] = None


def provider_error(name: str, exc):
    p = state["market"]["providers"].setdefault(name, {})
    p["status"] = "degraded"
    p["error"] = str(exc)[:180]


def fetch_json(url: str, params: dict | None = None, headers: dict | None = None, timeout=8.0):
    all_headers = {"Accept": "application/json", "User-Agent": USER_AGENT}
    if headers:
        all_headers.update(headers)
    with httpx.Client(timeout=timeout, follow_redirects=True, headers=all_headers) as client:
        response = client.get(url, params=params)
        response.raise_for_status()
        return response.json()


def check_optional_helius():
    key = os.getenv("HELIUS_API_KEY")
    if not key:
        state["market"]["providers"]["helius"].update({"status": "optional", "configured": False})
        return
    try:
        with httpx.Client(timeout=5.0, headers={"Content-Type": "application/json", "User-Agent": USER_AGENT}) as client:
            r = client.post(f"https://mainnet.helius-rpc.com/?api-key={key}", json={"jsonrpc": "2.0", "id": 1, "method": "getHealth"})
            r.raise_for_status()
            payload = r.json()
            if payload.get("result") != "ok":
                raise RuntimeError(str(payload)[:140])
        state["market"]["providers"]["helius"].update({"status": "live", "configured": True, "last_ok": int(time.time()), "error": None})
    except Exception as exc:
        state["market"]["providers"]["helius"].update({"status": "degraded", "configured": True, "error": str(exc)[:180]})


def extract_gecko_token_addresses(payload: dict) -> list[str]:
    addresses = []
    for item in (payload or {}).get("data", []) or []:
        try:
            rel = item.get("relationships", {}).get("base_token", {}).get("data", {})
            rid = str(rel.get("id") or "")
            if rid.startswith("solana_"):
                addresses.append(rid.split("_", 1)[1])
        except Exception:
            continue
    return addresses


def discover_live_addresses() -> tuple[list[str], dict[str, set[str]], dict[str, dict]]:
    sources: dict[str, set[str]] = {}
    metadata: dict[str, dict] = {}
    addresses: list[str] = []

    def add(address, source, meta=None):
        address = str(address or "").strip()
        if not address:
            return
        if address not in sources:
            addresses.append(address)
            sources[address] = set()
        sources[address].add(source)
        if meta:
            metadata[address] = {**metadata.get(address, {}), **meta}

    jobs = {
        "dex_top": (f"{DEX_BASE}/token-boosts/top/v1", None, None),
        "dex_latest": (f"{DEX_BASE}/token-boosts/latest/v1", None, None),
        "dex_profiles": (f"{DEX_BASE}/token-profiles/latest/v1", None, None),
        "gecko_trending": (f"{GECKO_BASE}/networks/solana/trending_pools", {"include": "base_token"}, {"Accept": "application/json;version=20230203"}),
        "gecko_new": (f"{GECKO_BASE}/networks/solana/new_pools", {"include": "base_token", "page": 1}, {"Accept": "application/json;version=20230203"}),
    }
    results, errors = {}, {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        future_map = {executor.submit(fetch_json, url, params, headers, 6.0): name for name, (url, params, headers) in jobs.items()}
        for future in concurrent.futures.as_completed(future_map):
            name = future_map[future]
            try:
                results[name] = future.result()
            except Exception as exc:
                errors[name] = exc

    rows = lambda payload: payload if isinstance(payload, list) else ([payload] if isinstance(payload, dict) else [])
    for row in rows(results.get("dex_top")):
        if row.get("chainId") == "solana": add(row.get("tokenAddress"), "dex_boost_top", row)
    for row in rows(results.get("dex_latest")):
        if row.get("chainId") == "solana": add(row.get("tokenAddress"), "dex_boost_latest", row)
    for row in rows(results.get("dex_profiles")):
        if row.get("chainId") == "solana": add(row.get("tokenAddress"), "dex_profile", row)
    if any(k in results for k in ("dex_top", "dex_latest", "dex_profiles")):
        provider_ok("dexscreener")
    elif any(k.startswith("dex_") for k in errors):
        provider_error("dexscreener", next(v for k, v in errors.items() if k.startswith("dex_")))

    for address in extract_gecko_token_addresses(results.get("gecko_trending") or {}): add(address, "gecko_trending")
    for address in extract_gecko_token_addresses(results.get("gecko_new") or {}): add(address, "gecko_new")
    if any(k in results for k in ("gecko_trending", "gecko_new")):
        provider_ok("geckoterminal")
    elif any(k.startswith("gecko_") for k in errors):
        provider_error("geckoterminal", next(v for k, v in errors.items() if k.startswith("gecko_")))

    for pos in state.get("positions", []): add(pos.get("token_address"), "open_position")
    for address in state.get("watchlist", []): add(address, "watchlist")
    return addresses[:30], sources, metadata


def choose_best_pair(pairs: list[dict], token_address: str | None = None) -> dict | None:
    candidates = []
    for pair in pairs or []:
        if pair.get("chainId") != "solana" or not pair.get("priceUsd"):
            continue
        if token_address and pair.get("baseToken", {}).get("address") != token_address:
            continue
        liq = fnum((pair.get("liquidity") or {}).get("usd"))
        vol = fnum((pair.get("volume") or {}).get("h24"))
        # Prefer liquid/active pools. Liquidity matters more than a single burst of volume.
        rank = liq * 1.0 + min(vol, liq * 10) * 0.12
        candidates.append((rank, pair))
    return max(candidates, key=lambda x: x[0])[1] if candidates else None


def batch_dex_pairs(addresses: list[str]) -> dict[str, dict]:
    if not addresses:
        return {}
    result: dict[str, dict] = {}
    for start in range(0, len(addresses), 30):
        batch = addresses[start:start + 30]
        payload = fetch_json(f"{DEX_BASE}/tokens/v1/solana/{','.join(batch)}")
        by_address: dict[str, list[dict]] = {a: [] for a in batch}
        for pair in payload or []:
            base = (pair.get("baseToken") or {}).get("address")
            if base in by_address:
                by_address[base].append(pair)
        for address, pairs in by_address.items():
            best = choose_best_pair(pairs, address)
            if best:
                result[address] = best
    provider_ok("dexscreener")
    return result


def score_live_pair(pair: dict, source_tags: set[str], profile_meta: dict | None = None) -> dict:
    txns = pair.get("txns") or {}
    volume = pair.get("volume") or {}
    changes = pair.get("priceChange") or {}
    liquidity_usd = fnum((pair.get("liquidity") or {}).get("usd"))
    m5_buys = inum((txns.get("m5") or {}).get("buys"))
    m5_sells = inum((txns.get("m5") or {}).get("sells"))
    h1_buys = inum((txns.get("h1") or {}).get("buys"))
    h1_sells = inum((txns.get("h1") or {}).get("sells"))
    m5_total = m5_buys + m5_sells
    h1_total = h1_buys + h1_sells
    buy_ratio = (m5_buys + 1) / (m5_total + 2)
    p5 = fnum(changes.get("m5"))
    p1 = fnum(changes.get("h1"))
    vol5 = fnum(volume.get("m5"))
    vol1 = fnum(volume.get("h1"))
    vol24 = fnum(volume.get("h24"))
    market_cap = fnum(pair.get("marketCap")) or fnum(pair.get("fdv"))
    fdv = fnum(pair.get("fdv"))
    pair_age = age_minutes(pair.get("pairCreatedAt"))
    boosts = inum((pair.get("boosts") or {}).get("active"))
    socials = ((pair.get("info") or {}).get("socials") or [])
    websites = ((pair.get("info") or {}).get("websites") or [])

    liq_score = clamp(20 + 22 * math.log10(max(1.0, liquidity_usd) / 1000 + 1))
    activity = clamp(20 + min(55, h1_total * 0.8) + min(25, vol1 / max(1000.0, liquidity_usd) * 35))
    momentum = clamp(50 + p5 * 1.3 + p1 * 0.22 + (buy_ratio - 0.5) * 80)

    safety = 45.0
    hard_risks = []
    if liquidity_usd >= 10000: safety += 12
    else: hard_risks.append("thin liquidity")
    if liquidity_usd >= 50000: safety += 8
    if pair_age is not None:
        if pair_age >= 10: safety += 8
        if pair_age < 3:
            safety -= 20; hard_risks.append("pool under 3 minutes old")
    if h1_sells > 0: safety += 7
    elif h1_buys > 8:
        safety -= 14; hard_risks.append("no recent sells observed")
    if market_cap and liquidity_usd:
        cap_liq = market_cap / max(1.0, liquidity_usd)
        if cap_liq <= 30: safety += 8
        elif cap_liq > 150:
            safety -= 12; hard_risks.append("high valuation vs liquidity")
    safety = clamp(safety)

    community = 35 + min(22, boosts * 2) + min(18, len(socials) * 7) + min(10, len(websites) * 5)
    if "gecko_trending" in source_tags: community += 12
    if "dex_boost_top" in source_tags: community += 8
    community = clamp(community)

    entry = 78.0
    if p5 > 20: entry -= (p5 - 20) * 0.9
    if p5 > 50: hard_risks.append("5m move is heavily extended")
    if p5 < -12: entry -= 22
    if p1 > 120: entry -= 18
    if buy_ratio > 0.62: entry += 8
    if liquidity_usd < 10000: entry -= 20
    entry = clamp(entry)

    launch = 55.0
    if pair_age is not None:
        if 5 <= pair_age <= 180: launch = 88
        elif pair_age <= 1440: launch = 76
        elif pair_age <= 10080: launch = 62
    if "gecko_new" in source_tags: launch = min(100, launch + 8)

    master = round(
        momentum * .20 + liq_score * .18 + safety * .22 + activity * .16 +
        community * .10 + entry * .14
    )
    threshold = risk_threshold()
    if safety < 50 or liq_score < 42 or liquidity_usd < float(state["settings"]["min_liquidity_usd"]):
        decision = "REJECT"
    elif master >= threshold and entry >= 55:
        decision = "BUY"
    elif master >= 68:
        decision = "WATCH"
    else:
        decision = "REJECT"

    reasons = []
    if buy_ratio >= .60: reasons.append(f"buyers {buy_ratio*100:.0f}% of 5m flow")
    if p5 >= 5: reasons.append(f"5m momentum +{p5:.1f}%")
    if liquidity_usd >= 50000: reasons.append(f"liquidity ${liquidity_usd:,.0f}")
    if vol1 >= liquidity_usd * .5 and liquidity_usd > 0: reasons.append("strong volume/liquidity turnover")
    if "gecko_trending" in source_tags: reasons.append("GeckoTerminal trending")
    if boosts: reasons.append(f"{boosts} active DEX boost(s)")
    if hard_risks: reasons.extend([f"RISK: {x}" for x in hard_risks[:2]])
    if not reasons: reasons.append("live market setup requires more confirmation")

    return {
        "momentum": round(momentum),
        "liquidity": round(liq_score),
        "safety": round(safety),
        "activity": round(activity),
        "community": round(community),
        "social": round(community),  # compatibility: community signal, not X virality
        "smart_money": round(activity),  # compatibility UI is relabelled Flow in 1.3
        "entry_quality": round(entry),
        "pattern": round(entry),
        "launch": round(launch),
        "master_score": master,
        "decision": decision,
        "reasons": reasons,
        "reason": reasons[0],
        "hard_risks": hard_risks,
        "buy_ratio_5m": round(buy_ratio * 100, 1),
        "buys_m5": m5_buys,
        "sells_m5": m5_sells,
        "buys_h1": h1_buys,
        "sells_h1": h1_sells,
        "volume_m5": vol5,
        "volume_h1": vol1,
        "volume_h24": vol24,
        "price_change_m5": p5,
        "price_change_h1": p1,
        "liquidity_usd": liquidity_usd,
        "market_cap": market_cap,
        "fdv": fdv,
        "pair_age_minutes": pair_age,
        "boosts_active": boosts,
    }


def live_links(pair: dict, token_address: str, launchpad: str):
    info = pair.get("info") or {}
    x_link = None
    for social in info.get("socials") or []:
        if str(social.get("platform", "")).lower() in {"twitter", "x"}:
            handle = social.get("handle")
            if handle:
                x_link = f"https://x.com/{str(handle).lstrip('@')}"
                break
    if not x_link:
        x_link = f"https://x.com/search?q={quote('$' + str((pair.get('baseToken') or {}).get('symbol', '')))}&src=typed_query"
    return {
        "dexscreener": pair.get("url") or f"https://dexscreener.com/solana/{pair.get('pairAddress', '')}",
        "pumpfun": f"https://pump.fun/coin/{token_address}" if launchpad == "Pump.fun" else None,
        "robinhood": None,
        "x": x_link,
    }


def normalize_live_token(address: str, pair: dict, tags: set[str], meta: dict | None = None):
    base = pair.get("baseToken") or {}
    labels = [str(x).lower() for x in (pair.get("labels") or [])]
    dex_id = str(pair.get("dexId") or "")
    is_pump = "pump" in dex_id.lower() or any("pump" in x for x in labels) or str(address).endswith("pump")
    launchpad = "Pump.fun" if is_pump else dex_id.replace("-", " ").title() or "Solana DEX"
    scores = score_live_pair(pair, tags, meta)
    image = (pair.get("info") or {}).get("imageUrl") or (meta or {}).get("icon")
    return {
        "name": base.get("name") or "Unknown",
        "symbol": base.get("symbol") or address[:6],
        "chain": "Solana",
        "launchpad": launchpad,
        "logo": "●",
        "image_url": image,
        "token_address": address,
        "pair_address": pair.get("pairAddress"),
        "dex_id": dex_id,
        "price": fnum(pair.get("priceUsd")),
        "price_usd": fnum(pair.get("priceUsd")),
        "links": live_links(pair, address, launchpad),
        "source_tags": sorted(tags),
        "is_live": True,
        "is_demo": False,
        "observed_at": int(time.time()),
        **scores,
    }


def enrich_pumpfun_token(token: dict):
    if token.get("launchpad") != "Pump.fun" or not token.get("token_address"):
        return token
    try:
        payload = fetch_json(f"https://frontend-api-v3.pump.fun/coins-v2/{token['token_address']}", timeout=3.5)
        coin = payload.get("data") if isinstance(payload, dict) and isinstance(payload.get("data"), dict) else payload
        if isinstance(coin, dict):
            token["pump"] = {
                "complete": bool(coin.get("complete")),
                "status": "GRADUATED" if coin.get("complete") else "BONDING",
                "creator": coin.get("creator"),
                "created_timestamp": coin.get("created_timestamp"),
                "bonding_curve": coin.get("bonding_curve"),
                "pump_swap_pool": coin.get("pump_swap_pool") or coin.get("raydium_pool"),
                "usd_market_cap": fnum(coin.get("usd_market_cap")),
                "reply_count": inum(coin.get("reply_count")),
            }
            if coin.get("image_uri") and not token.get("image_url"):
                token["image_url"] = coin.get("image_uri")
            provider_ok("pumpfun")
    except Exception as exc:
        provider_error("pumpfun", exc)
    return token


def run_market_scan():
    check_optional_helius()
    addresses, sources, metadata = discover_live_addresses()
    if not addresses:
        raise RuntimeError("No live Solana candidates returned by market providers")
    pairs_by_addr = batch_dex_pairs(addresses)
    results = []
    for address in addresses:
        pair = pairs_by_addr.get(address)
        if not pair:
            continue
        token = normalize_live_token(address, pair, sources.get(address, set()), metadata.get(address))
        if token["price"] <= 0:
            continue
        # Keep a broad scanner but discard essentially untradeable dust pools.
        if token["liquidity_usd"] < 1000:
            continue
        results.append(token)
    results.sort(key=lambda x: (x["master_score"], x["volume_h1"], x["liquidity_usd"]), reverse=True)
    # Enrich only the leading Pump.fun candidates to stay gentle on the public frontend API.
    pump_enriched = 0
    for token in results:
        if token.get("launchpad") == "Pump.fun" and pump_enriched < 2:
            enrich_pumpfun_token(token)
            pump_enriched += 1
    if not results:
        raise RuntimeError("Live providers responded but no usable Solana pairs passed basic liquidity checks")
    state["scanner"] = results[:12]
    now = int(time.time())
    state["last_scan"] = now
    state["market"]["last_scan_at"] = now
    state["market"]["last_good_market_at"] = now
    state["market"]["auto_paused_reason"] = None
    state["total_scans"] = int(state.get("total_scans", 0)) + len(results)
    state["status_message"] = f"LIVE Solana scan • {len(results)} real pairs ranked"
    save_state()
    return results


def update_open_position_prices():
    positions = [p for p in state.get("positions", []) if p.get("token_address")]
    if not positions:
        return
    addresses = list(dict.fromkeys(p["token_address"] for p in positions))[:30]
    pairs = batch_dex_pairs(addresses)
    updated = 0
    now = int(time.time())
    for pos in positions:
        pair = pairs.get(pos["token_address"])
        if not pair:
            continue
        price = fnum(pair.get("priceUsd"))
        if price <= 0:
            continue
        pos["current_price"] = price
        pos["current_value"] = pos["qty"] * price
        pos["last_price_at"] = now
        pos["liquidity_usd"] = fnum((pair.get("liquidity") or {}).get("usd"))
        gain_pct = ((pos["current_value"] / max(.000001, pos["cost_basis"])) - 1) * 100
        pos["mfe_pct"] = max(fnum(pos.get("mfe_pct")), gain_pct)
        pos["mae_pct"] = min(fnum(pos.get("mae_pct")), gain_pct)
        updated += 1
    if updated:
        state["market"]["last_position_price_at"] = now
        state["market"]["last_good_market_at"] = max(state["market"].get("last_good_market_at", 0), now)
        save_state()


def market_is_fresh(max_age=90):
    last = inum(state.get("market", {}).get("last_good_market_at"))
    return bool(last and time.time() - last <= max_age)


def risk_threshold():
    mode_floor = {"safe": 88, "balanced": 82, "aggressive": 76}[state["settings"]["risk_mode"]]
    return max(mode_floor, int(state["settings"]["min_score"]))


def portfolio_value():
    return state["cash"] + sum(fnum(p.get("current_value")) for p in state["positions"])


def deployed_capital():
    return sum(fnum(p.get("cost_basis")) for p in state["positions"])


def unrealized_pnl():
    return sum(fnum(p.get("current_value")) - fnum(p.get("cost_basis")) for p in state["positions"])


def total_daily_pnl():
    return fnum(state.get("realized_pnl")) + unrealized_pnl()


def portfolio_heat_pct():
    return deployed_capital() / max(1.0, float(state.get("starting_balance", 10000))) * 100


def performance_summary():
    trades = [h for h in state.get("history", []) if h.get("is_live")]
    pnls = [fnum(h.get("realized_pnl")) for h in trades]
    wins = [x for x in pnls if x > 0]
    losses = [x for x in pnls if x < 0]
    win_rate = (len(wins) / len(pnls) * 100) if pnls else 0.0
    avg_win = sum(wins) / len(wins) if wins else 0.0
    avg_loss = sum(losses) / len(losses) if losses else 0.0
    gross_profit = sum(wins)
    gross_loss = abs(sum(losses))
    profit_factor = gross_profit / gross_loss if gross_loss > 0 else (gross_profit if gross_profit > 0 else 0.0)
    expectancy = sum(pnls) / len(pnls) if pnls else 0.0
    return {
        "closed_trades": len(pnls), "wins": len(wins), "losses": len(losses), "win_rate": win_rate,
        "avg_win": avg_win, "avg_loss": avg_loss, "profit_factor": profit_factor, "expectancy": expectancy,
        "gross_profit": gross_profit, "gross_loss": gross_loss,
    }


def check_day_rollover():
    today = datetime.now(SYDNEY).date().isoformat()
    if today != state["day_key"]:
        state["day_key"] = today
        state["realized_pnl"] = 0.0
        state["approved_today"] = 0
        state["status_message"] = "New Sydney trading day started"
        save_state()


def apply_guardrails():
    pnl = total_daily_pnl()
    settings = state["settings"]
    if pnl <= -settings["daily_loss_limit"]:
        state["bot_on"] = False
        state["status_message"] = f"Daily loss stop reached: -${abs(pnl):.2f}. Auto trading stopped."
    elif settings.get("daily_profit_stop_enabled", False) and pnl >= settings.get("daily_profit_stop_limit", 1000):
        state["bot_on"] = False
        state["status_message"] = f"Optional daily profit stop reached: +${pnl:.2f}. Auto trading stopped."


def estimated_slippage_pct(amount: float, liquidity_usd: float):
    if liquidity_usd <= 0:
        return 5.0
    impact = amount / liquidity_usd * 75.0
    return clamp(max(0.15, impact), 0.15, 5.0)


def find_scanner_token(symbol=None, token_address=None):
    if token_address:
        return next((x for x in state["scanner"] if x.get("token_address") == token_address), None)
    if symbol:
        # Prefer exact symbol and highest score if duplicates exist.
        matches = [x for x in state["scanner"] if x.get("symbol") == symbol]
        return max(matches, key=lambda x: x.get("master_score", 0)) if matches else None
    return None


def open_paper_position(symbol: str | None, amount: float, source="manual", token_address: str | None = None):
    settings = state["settings"]
    if amount < 5:
        raise HTTPException(status_code=400, detail="Minimum trade amount is $5")
    if len(state["positions"]) >= settings["max_positions"]:
        raise HTTPException(status_code=400, detail="Maximum open positions reached")
    if amount > state["cash"]:
        raise HTTPException(status_code=400, detail="Insufficient paper cash")
    if portfolio_heat_pct() + amount / state["starting_balance"] * 100 > settings["max_portfolio_heat_pct"]:
        raise HTTPException(status_code=400, detail="Portfolio heat limit would be exceeded")
    token = find_scanner_token(symbol=symbol, token_address=token_address)
    if not token:
        raise HTTPException(status_code=404, detail="Token not found in current live scan")
    if not token.get("is_live") or token.get("price", 0) <= 0:
        raise HTTPException(status_code=400, detail="Live price unavailable for this token")

    market_price = float(token["price"])
    liquidity = float(token.get("liquidity_usd") or 0)
    slippage_pct = estimated_slippage_pct(amount, liquidity)
    fee = max(0.01, amount * 0.003)
    fill_price = market_price * (1 + slippage_pct / 100)
    tradable = max(0.0, amount - fee)
    qty = tradable / fill_price
    position = {
        "id": state["next_position_id"],
        "symbol": token["symbol"],
        "name": token["name"],
        "chain": "Solana",
        "launchpad": token["launchpad"],
        "logo": token.get("logo", "●"),
        "image_url": token.get("image_url"),
        "token_address": token["token_address"],
        "pair_address": token.get("pair_address"),
        "entry_market_price": market_price,
        "entry_price": fill_price,
        "current_price": market_price,
        "qty": qty,
        "cost_basis": amount,
        "current_value": qty * market_price,
        "opened_at": int(time.time()),
        "last_price_at": int(time.time()),
        "master_score": token["master_score"],
        "safety": token["safety"],
        "community": token["community"],
        "momentum": token["momentum"],
        "activity": token["activity"],
        "entry_quality": token["entry_quality"],
        "source": source,
        "scale_count": 0,
        "last_scale_at": 0,
        "links": token["links"],
        "is_live": True,
        "is_demo": False,
        "entry_fee": fee,
        "entry_slippage_pct": slippage_pct,
        "liquidity_usd": liquidity,
        "mfe_pct": 0.0,
        "mae_pct": 0.0,
        "entry_reasons": token.get("reasons", []),
        "strategy_version": STRATEGY_VERSION,
    }
    state["next_position_id"] += 1
    state["cash"] -= amount
    state["positions"].append(position)
    if source == "auto":
        state["approved_today"] = int(state.get("approved_today", 0)) + 1
        state["last_auto_trade_at"] = int(time.time())
    state["status_message"] = f"LIVE-MARKET PAPER BUY • {token['symbol']} • ${amount:.2f}"
    save_state()
    return position


def scale_position(pos):
    mode = state["settings"]["auto_scale"]
    if mode == "off" or not market_is_fresh():
        return False
    config = {
        "low": {"max": 1, "trigger": 40, "fraction": .5},
        "medium": {"max": 2, "trigger": 30, "fraction": .5},
        "high": {"max": 3, "trigger": 25, "fraction": .5},
    }[mode]
    if pos.get("scale_count", 0) >= config["max"] or time.time() - pos.get("last_scale_at", 0) < 60:
        return False
    gain_pct = ((pos["current_value"] / max(.000001, pos["cost_basis"])) - 1) * 100
    if gain_pct < config["trigger"] * (pos.get("scale_count", 0) + 1):
        return False
    add_amount = min(float(state["settings"]["auto_trade_size"]) * config["fraction"], state["cash"])
    if add_amount < 5:
        return False
    if portfolio_heat_pct() + add_amount / state["starting_balance"] * 100 > state["settings"]["max_portfolio_heat_pct"]:
        return False
    slip = estimated_slippage_pct(add_amount, fnum(pos.get("liquidity_usd")))
    fee = max(.01, add_amount * .003)
    fill = pos["current_price"] * (1 + slip / 100)
    pos["qty"] += (add_amount - fee) / fill
    pos["cost_basis"] += add_amount
    pos["current_value"] = pos["qty"] * pos["current_price"]
    pos["scale_count"] = pos.get("scale_count", 0) + 1
    pos["last_scale_at"] = int(time.time())
    state["cash"] -= add_amount
    state["status_message"] = f"Auto scaled live-market paper position {pos['symbol']} by ${add_amount:.2f}"
    save_state()
    return True


def close_position(position_id: int, percent: float, exit_reason="manual"):
    pos = next((p for p in state["positions"] if p["id"] == position_id), None)
    if not pos:
        raise HTTPException(status_code=404, detail="Position not found")
    fraction = percent / 100.0
    qty_sold = pos["qty"] * fraction
    mark_value = qty_sold * pos["current_price"]
    slip = estimated_slippage_pct(mark_value, fnum(pos.get("liquidity_usd")))
    gross = mark_value * (1 - slip / 100)
    exit_fee = max(.01, gross * .003)
    net = max(0.0, gross - exit_fee)
    sold_cost = pos["cost_basis"] * fraction
    realized = net - sold_cost
    pnl_pct = realized / max(.000001, sold_cost) * 100

    state["cash"] += net
    state["realized_pnl"] += realized
    state["history"].append({
        "symbol": pos["symbol"], "token_address": pos.get("token_address"), "logo": pos.get("logo", "●"),
        "percent": percent, "realized_pnl": realized, "pnl_pct": pnl_pct, "sold_value": net,
        "closed_at": int(time.time()), "opened_at": pos.get("opened_at"), "duration_seconds": int(time.time()) - int(pos.get("opened_at", time.time())),
        "exit_reason": exit_reason, "entry_score": pos.get("master_score"), "mfe_pct": pos.get("mfe_pct"), "mae_pct": pos.get("mae_pct"),
        "entry_price": pos.get("entry_price"), "exit_market_price": pos.get("current_price"), "exit_slippage_pct": slip,
        "entry_fee": pos.get("entry_fee", 0), "exit_fee": exit_fee, "entry_reasons": pos.get("entry_reasons", []), "is_live": True,
        "strategy_version": pos.get("strategy_version", STRATEGY_VERSION),
    })
    if percent >= 99.999:
        state["positions"].remove(pos)
    else:
        pos["qty"] -= qty_sold
        pos["cost_basis"] -= sold_cost
        pos["current_value"] = pos["qty"] * pos["current_price"]
    state["status_message"] = f"LIVE-MARKET PAPER SELL • {percent:g}% {pos['symbol']} • {exit_reason}"
    apply_guardrails()
    save_state()
    return {"realized_pnl": realized, "pnl_pct": pnl_pct, "net_value": net}


def maybe_manage_positions():
    if not market_is_fresh(45):
        return
    settings = state["settings"]
    for pos in list(state["positions"]):
        if time.time() - int(pos.get("last_price_at", 0)) > 45:
            continue
        gain_pct = ((pos["current_value"] / max(.000001, pos["cost_basis"])) - 1) * 100
        if gain_pct <= -float(settings["stop_loss_pct"]):
            close_position(pos["id"], 100, "stop_loss")
        elif gain_pct >= float(settings["take_profit_pct"]):
            close_position(pos["id"], 100, "take_profit")
        else:
            scale_position(pos)


def can_auto_enter():
    s = state["settings"]
    if not market_is_fresh(90):
        state["market"]["auto_paused_reason"] = "Live market feed is stale — entries paused"
        return False
    if len(state["positions"]) >= s["max_positions"]:
        state["market"]["auto_paused_reason"] = "Maximum positions reached"
        return False
    if portfolio_heat_pct() >= s["max_portfolio_heat_pct"]:
        state["market"]["auto_paused_reason"] = "Portfolio heat limit reached"
        return False
    if time.time() - int(state.get("last_auto_trade_at", 0)) < s["entry_cooldown_seconds"]:
        state["market"]["auto_paused_reason"] = "Entry cooldown active"
        return False
    state["market"]["auto_paused_reason"] = None
    return True


async def engine_loop():
    last_price_refresh = 0.0
    while True:
        try:
            check_day_rollover()
            settings = state["settings"]
            now = time.time()

            if state["positions"] and now - last_price_refresh >= 8:
                try:
                    await asyncio.to_thread(update_open_position_prices)
                except Exception as exc:
                    provider_error("dexscreener", exc)
                last_price_refresh = now

            maybe_manage_positions()
            apply_guardrails()

            scan_interval = max(15, int(settings["scan_interval_seconds"]))
            if not state.get("last_scan") or now - int(state["last_scan"]) >= scan_interval:
                try:
                    await asyncio.to_thread(run_market_scan)
                except Exception as exc:
                    state["status_message"] = f"LIVE DATA DEGRADED • {str(exc)[:110]}"
                    if not market_is_fresh(90):
                        state["market"]["auto_paused_reason"] = "Live market feed unavailable — auto entries paused"

            if state["bot_on"] and settings["mode"] == "auto" and can_auto_enter():
                held = {p.get("token_address") for p in state["positions"]}
                candidates = [
                    t for t in state["scanner"]
                    if t.get("decision") == "BUY" and t.get("master_score", 0) >= risk_threshold()
                    and t.get("token_address") not in held and t.get("liquidity_usd", 0) >= settings["min_liquidity_usd"]
                ]
                if candidates:
                    amount = min(float(settings["auto_trade_size"]), state["cash"])
                    if amount >= 5:
                        open_paper_position(None, amount, source="auto", token_address=candidates[0]["token_address"])
            save_state()
        except Exception as exc:
            state["status_message"] = f"Engine warning: {str(exc)[:140]}"
        await asyncio.sleep(2)


@app.on_event("startup")
async def startup_event():
    load_state()
    state["status_message"] = "Stage 1.3 online • connecting to live Solana market feeds…"
    # Never block app startup on an external provider. The engine acquires the first live scan in background.
    asyncio.create_task(engine_loop())


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


def wallet_summary():
    return {
        "type": "paper_live_market",
        "status": "connected",
        "label": "Master Trader Live-Market Paper Wallet",
        "wallet_id": state.get("paper_wallet_id", "MT-PAPER"),
        "network": "Solana live market / paper execution",
        "networks": ["Solana mainnet market data"],
        "settlement_asset": "Paper USDC",
        "available_cash": state["cash"],
        "portfolio_value": portfolio_value(),
        "deployed_capital": deployed_capital(),
        "portfolio_heat_pct": portfolio_heat_pct(),
        "unrealized_pnl": unrealized_pnl(),
        "realized_pnl": state["realized_pnl"],
        "open_positions": len(state["positions"]),
        "live_keys_loaded": False,
        "private_key_required": False,
    }


def state_payload():
    check_day_rollover()
    return {
        **state,
        "portfolio_value": portfolio_value(),
        "deployed_capital": deployed_capital(),
        "portfolio_heat_pct": portfolio_heat_pct(),
        "unrealized_pnl": unrealized_pnl(),
        "daily_pnl": total_daily_pnl(),
        "presets": PRESETS,
        "risk_threshold": risk_threshold(),
        "version": APP_VERSION,
        "timezone": "Australia/Sydney",
        "wallet": wallet_summary(),
        "market_fresh": market_is_fresh(),
        "performance": performance_summary(),
        "strategy_version": STRATEGY_VERSION,
    }


@app.get("/api/wallet")
def get_wallet():
    return wallet_summary()


@app.get("/api/state")
def get_state():
    return state_payload()


@app.post("/api/control")
def update_control(req: ControlRequest):
    settings_data = dict(state.get("settings", Settings().model_dump()))
    if req.mode is not None:
        settings_data["mode"] = req.mode
    if req.auto_trade_size is not None:
        settings_data["auto_trade_size"] = float(req.auto_trade_size)
    settings = Settings(**settings_data)
    state["settings"] = settings.model_dump()
    blocked = None
    if req.bot_on is not None:
        if req.bot_on and settings.mode == "paper":
            state["bot_on"] = False
            blocked = "Manual mode selected. Use Trade Desk or select AUTO."
        elif req.bot_on and total_daily_pnl() <= -settings.daily_loss_limit:
            state["bot_on"] = False
            blocked = "Daily loss stop is already reached."
        else:
            state["bot_on"] = bool(req.bot_on)
    if state["bot_on"]:
        if settings.mode == "auto":
            state["status_message"] = f"AUTO ARMED • LIVE Solana feed • ${settings.auto_trade_size:.0f}/trade"
        else:
            state["status_message"] = "ASSISTED scanner active • live market data"
    else:
        state["status_message"] = blocked or "Trading engine paused"
    save_state()
    payload = state_payload()
    payload["control_blocked"] = blocked
    return payload


@app.post("/api/settings")
def update_settings(settings: Settings):
    state["settings"] = settings.model_dump()
    apply_guardrails()
    state["status_message"] = "Live Intelligence settings saved"
    save_state()
    return state_payload()


@app.post("/api/bot/{action}")
def set_bot(action: Literal["on", "off"]):
    return update_control(ControlRequest(bot_on=action == "on"))


@app.post("/api/scan")
async def scan_market():
    try:
        await asyncio.to_thread(run_market_scan)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Live scan unavailable: {str(exc)[:160]}")
    return state_payload()


@app.post("/api/trade/open")
def open_trade(req: OpenTradeRequest):
    pos = open_paper_position(req.symbol, req.amount, "manual", req.token_address)
    return {"position": pos, "state": state_payload()}


@app.post("/api/trade/close")
def close_trade(req: CloseTradeRequest):
    result = close_position(req.position_id, req.percent, "manual")
    return {**result, "state": state_payload()}


@app.get("/api/market/search")
async def market_search(q: str = Query(min_length=2, max_length=100)):
    try:
        payload = await asyncio.to_thread(fetch_json, f"{DEX_BASE}/latest/dex/search", {"q": q})
        pairs = [p for p in (payload.get("pairs") or []) if p.get("chainId") == "solana" and p.get("priceUsd")]
        out = []
        seen = set()
        for pair in sorted(pairs, key=lambda p: fnum((p.get("liquidity") or {}).get("usd")), reverse=True):
            address = (pair.get("baseToken") or {}).get("address")
            if not address or address in seen:
                continue
            seen.add(address)
            t = normalize_live_token(address, pair, {"search"})
            out.append(t)
            if len(out) >= 10:
                break
        provider_ok("dexscreener")
        return {"results": out}
    except Exception as exc:
        provider_error("dexscreener", exc)
        raise HTTPException(status_code=503, detail=f"Live search unavailable: {str(exc)[:150]}")


@app.post("/api/market/watch/{token_address}")
async def add_watch(token_address: str):
    token_address = token_address.strip()
    if token_address not in state["watchlist"]:
        state["watchlist"].insert(0, token_address)
        state["watchlist"] = state["watchlist"][:20]
    try:
        pairs = await asyncio.to_thread(batch_dex_pairs, [token_address])
        pair = pairs.get(token_address)
        if pair:
            token = normalize_live_token(token_address, pair, {"watchlist"})
            state["scanner"] = [x for x in state["scanner"] if x.get("token_address") != token_address]
            state["scanner"].insert(0, token)
            state["scanner"] = state["scanner"][:12]
            state["market"]["last_good_market_at"] = int(time.time())
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"Could not load token: {str(exc)[:150]}")
    save_state()
    return state_payload()


def scanner_token_by_address(address: str):
    return next((t for t in state["scanner"] if t.get("token_address") == address), None)


@app.get("/api/market/chart/{token_address}")
async def market_chart(token_address: str, timeframe: Literal["1m", "5m", "15m", "1h"] = "5m"):
    key = (token_address, timeframe)
    cached = _chart_cache.get(key)
    if cached and time.time() - cached[0] < 25:
        return cached[1]
    token = scanner_token_by_address(token_address)
    pair_address = token.get("pair_address") if token else None
    if not pair_address:
        try:
            pairs = await asyncio.to_thread(batch_dex_pairs, [token_address])
            pair = pairs.get(token_address)
            pair_address = pair.get("pairAddress") if pair else None
        except Exception:
            pair_address = None
    if not pair_address:
        raise HTTPException(status_code=404, detail="Live pool not found for token")
    tf_map = {"1m": ("minute", 1), "5m": ("minute", 5), "15m": ("minute", 15), "1h": ("hour", 1)}
    tf, aggregate = tf_map[timeframe]
    try:
        payload = await asyncio.to_thread(
            fetch_json,
            f"{GECKO_BASE}/networks/solana/pools/{pair_address}/ohlcv/{tf}",
            {"aggregate": aggregate, "limit": 60, "currency": "usd"},
            {"Accept": "application/json;version=20230203"},
        )
        rows = (((payload or {}).get("data") or {}).get("attributes") or {}).get("ohlcv_list") or []
        candles = [
            {"t": int(r[0]), "o": fnum(r[1]), "h": fnum(r[2]), "l": fnum(r[3]), "c": fnum(r[4]), "v": fnum(r[5])}
            for r in rows if len(r) >= 6
        ]
        candles.sort(key=lambda x: x["t"])
        out = {"token_address": token_address, "pair_address": pair_address, "timeframe": timeframe, "candles": candles, "source": "GeckoTerminal", "live": True}
        _chart_cache[key] = (time.time(), out)
        provider_ok("geckoterminal")
        return out
    except Exception as exc:
        provider_error("geckoterminal", exc)
        raise HTTPException(status_code=503, detail=f"Live OHLCV unavailable: {str(exc)[:150]}")


@app.get("/api/market/trades/{token_address}")
async def market_trades(token_address: str):
    cached = _trades_cache.get(token_address)
    if cached and time.time() - cached[0] < 20:
        return cached[1]
    token = scanner_token_by_address(token_address)
    pair_address = token.get("pair_address") if token else None
    if not pair_address:
        raise HTTPException(status_code=404, detail="Live pool not found for token")
    try:
        payload = await asyncio.to_thread(
            fetch_json,
            f"{GECKO_BASE}/networks/solana/pools/{pair_address}/trades",
            None,
            {"Accept": "application/json;version=20230203"},
        )
        rows = []
        for item in (payload or {}).get("data", [])[:30]:
            a = item.get("attributes") or {}
            rows.append({
                "tx_hash": a.get("tx_hash"), "kind": a.get("kind") or a.get("kind_name"),
                "volume_usd": fnum(a.get("volume_in_usd")), "price_usd": fnum(a.get("price_from_in_usd") or a.get("price_to_in_usd")),
                "block_timestamp": a.get("block_timestamp"), "from_token_amount": a.get("from_token_amount"), "to_token_amount": a.get("to_token_amount"),
            })
        out = {"token_address": token_address, "pair_address": pair_address, "trades": rows, "source": "GeckoTerminal", "live": True}
        _trades_cache[token_address] = (time.time(), out)
        provider_ok("geckoterminal")
        return out
    except Exception as exc:
        provider_error("geckoterminal", exc)
        raise HTTPException(status_code=503, detail=f"Live trades unavailable: {str(exc)[:150]}")


@app.post("/api/reset/portfolio")
def reset_portfolio():
    state["cash"] = float(state.get("starting_balance", 10000.0))
    state["realized_pnl"] = 0.0
    state["positions"] = []
    state["history"] = []
    state["next_position_id"] = 1
    state["approved_today"] = 0
    state["last_auto_trade_at"] = 0
    state["status_message"] = "Live-market paper portfolio reset"
    save_state()
    return state_payload()


@app.post("/api/reset/settings")
def reset_settings():
    state["settings"] = Settings().model_dump()
    state["bot_on"] = False
    state["status_message"] = "Bot settings restored to Stage 1.3 defaults"
    save_state()
    return state_payload()


@app.post("/api/reset")
def reset_all():
    wallet_id = state.get("paper_wallet_id")
    state.clear()
    state.update(default_state())
    if wallet_id:
        state["paper_wallet_id"] = wallet_id
    save_state()
    return state_payload()


@app.get("/health")
def health():
    return {
        "ok": True,
        "version": APP_VERSION,
        "market_mode": "live",
        "paper_execution": True,
        "real_money_enabled": False,
        "market_fresh": market_is_fresh(),
        "providers": state.get("market", {}).get("providers", {}),
    }
