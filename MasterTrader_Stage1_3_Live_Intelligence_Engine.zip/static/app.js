// Master Trader 1.3.0 — Live Intelligence Engine + real Solana market data
(() => {
  'use strict';

  let appState = null;
  let selectedMode = 'paper';
  let autoTradeSize = 10;
  let chartSeries = [10000,10000,10000,10000,10000,10000,10000,10000];
  let lastBullKey = '';
  let sceneIndex = 0;
  let settingsDirty = false;
  let scannerView = 'trending';
  let controlBusy = false;
  let lastRevision = -1;
  let refreshTimer = null;
  let selectedChartAddress = null;
  let selectedTimeframe = '5m';
  let chartLoadNonce = 0;

  const $ = id => document.getElementById(id);
  const money = n => new Intl.NumberFormat('en-US', {style:'currency', currency:'USD', maximumFractionDigits:2}).format(Number(n)||0);
  const shortMoney = n => money(n).replace('.00','');
  const clamp = (n,a,b) => Math.max(a, Math.min(b,n));
  const modes = {paper:'MANUAL', assisted:'ASSISTED', auto:'AUTO'};

  function safeText(id, value){ const el=$(id); if(el) el.textContent=value; }
  function setDisabled(selector, disabled){ document.querySelectorAll(selector).forEach(el => el.disabled = disabled); }

  async function api(path, options={}){
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    try {
      const res = await fetch(path, {
        cache:'no-store',
        credentials:'same-origin',
        ...options,
        headers:{'Content-Type':'application/json', ...(options.headers||{})},
        signal:controller.signal
      });
      const text = await res.text();
      let data = {};
      if(text){
        try { data = JSON.parse(text); }
        catch { data = {detail:text.slice(0,220)}; }
      }
      if(!res.ok) throw new Error(data.detail || `Request failed (${res.status})`);
      return data;
    } catch(err){
      if(err?.name === 'AbortError') throw new Error('Request timed out. Please try again.');
      throw err;
    } finally { clearTimeout(timer); }
  }

  function toast(message, bad=false){
    const t=$('toast'); if(!t) return;
    t.textContent=message;
    t.className='toast ' + (bad?'bad':'good');
    clearTimeout(window.__mtToast);
    window.__mtToast=setTimeout(() => t.classList.add('hidden'), 2800);
  }

  function go(page){
    document.querySelectorAll('.page').forEach(p => p.classList.toggle('active', p.dataset.page===page));
    document.querySelectorAll('[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav===page));
    try { window.scrollTo({top:0, behavior:'smooth'}); } catch { window.scrollTo(0,0); }
    if(page==='scan' && selectedChartAddress) setTimeout(()=>loadLiveChart(selectedChartAddress,selectedTimeframe),80);
  }

  function rotateBull(){
    const scenes=[...document.querySelectorAll('.bull-scene')];
    if(!scenes.length) return;
    scenes.forEach((s,i)=>s.classList.toggle('active', i===sceneIndex));
    sceneIndex=(sceneIndex+1)%scenes.length;
  }

  function setSaveState(dirty){
    settingsDirty=dirty;
    const label=$('settingsSaveState');
    if(label){
      label.textContent=dirty?'Unsaved changes — press SAVE CHANGES to apply them.':'Settings saved and active.';
      label.classList.toggle('dirty', dirty);
    }
    const btn=$('saveSettings');
    if(btn){ btn.classList.toggle('dirty', dirty); btn.textContent=dirty?'SAVE CHANGES':'SAVED ✓'; }
  }
  function markSettingsDirty(){ setSaveState(true); }

  function setBusy(busy){
    controlBusy=busy;
    setDisabled('.mode-selector button, #autoPresetRow button, #applyAutoCustom, #botToggle', busy);
    document.body.classList.toggle('controls-busy', busy);
  }

  function setPresetButtons(value){
    document.querySelectorAll('#autoPresetRow button').forEach(b => {
      b.classList.toggle('selected', b.dataset.value!=='custom' && Number(b.dataset.value)===Number(value));
    });
    const standard=[5,10,15,20,50,100].includes(Number(value));
    const row=$('autoCustomRow'); if(row) row.classList.toggle('hidden', standard);
    if(!standard && $('autoCustomTrade')) $('autoCustomTrade').value=value;
  }

  function currentSettings(){
    const s=appState?.settings || {};
    return {
      auto_trade_size: Math.max(5, Number($('autoTradeInput')?.value)||autoTradeSize||10),
      manual_trade_size: Math.max(5, Number($('manualTradeInput')?.value)||s.manual_trade_size||10),
      daily_target: Math.max(1, Number($('dailyTarget')?.value)||500),
      daily_loss_limit: Math.max(1, Number($('dailyLoss')?.value)||250),
      max_positions: clamp(Number($('maxPositions')?.value)||5,1,50),
      risk_mode: $('riskMode')?.value || 'balanced',
      mode: selectedMode,
      daily_profit_stop_enabled: Boolean($('dailyProfitStopEnabled')?.checked),
      daily_profit_stop_limit: Math.max(1, Number($('dailyProfitStopLimit')?.value)||1000),
      auto_scale: $('autoScale')?.value || 'off',
      min_score: clamp(Number($('minScore')?.value)||82,60,99),
      stop_loss_pct: clamp(Number($('stopLoss')?.value)||15,1,80),
      take_profit_pct: clamp(Number($('takeProfit')?.value)||60,2,1000),
      scan_interval_seconds: clamp(Number($('scanInterval')?.value)||30,15,300),
      min_liquidity_usd: Math.max(1000, Number($('minLiquidity')?.value)||10000),
      max_portfolio_heat_pct: clamp(Number($('maxPortfolioHeat')?.value)||30,5,100),
      entry_cooldown_seconds: clamp(Number($('entryCooldown')?.value)||30,10,1800)
    };
  }

  function acceptState(s, force=false){
    if(!s || typeof s !== 'object') return false;
    const rev=Number(s.revision ?? -1);
    if(!force && rev >= 0 && rev < lastRevision) return false;
    if(rev >= 0) lastRevision=Math.max(lastRevision, rev);
    return true;
  }

  async function persistSettings(silent=false){
    setBusy(true);
    try {
      const s=await api('/api/settings', {method:'POST', body:JSON.stringify(currentSettings())});
      if(acceptState(s,true)) renderState(s,{forceInputs:true});
      setSaveState(false);
      if(!silent) toast('Settings saved and active');
      return s;
    } catch(err){
      toast('Save failed: '+(err?.message||'Unknown error'), true);
      throw err;
    } finally { setBusy(false); }
  }

  async function applyControl(patch, successMessage='Control updated'){
    setBusy(true);
    try {
      const result=await api('/api/control', {method:'POST', body:JSON.stringify(patch)});
      if(acceptState(result,true)) renderState(result,{forceInputs:true});
      if(result.control_blocked) toast(result.control_blocked,true);
      else if(successMessage) toast(successMessage);
      return result;
    } catch(err){
      toast('Control failed: '+(err?.message||'Unknown error'), true);
      throw err;
    } finally { setBusy(false); }
  }

  function updateModeUI(){
    document.querySelectorAll('[data-mode]').forEach(b => b.classList.toggle('active', b.dataset.mode===selectedMode));
    safeText('modeStatus', `${modes[selectedMode]} • LIVE MARKET / PAPER`);
    safeText('tradeModeReadout', modes[selectedMode]);
    safeText('controlMode', modes[selectedMode]);
    const cta=$('botToggle');
    if(cta){
      cta.classList.toggle('on', selectedMode!=='paper' && Boolean(appState?.bot_on));
      const label=cta.querySelector('b');
      if(label){
        if(selectedMode==='paper') label.textContent='OPEN MANUAL TRADE DESK';
        else if(selectedMode==='assisted') label.textContent=appState?.bot_on?'PAUSE AI SCANNER':'START AI SCANNER';
        else label.textContent=appState?.bot_on?'PAUSE AUTO TRADING':'START AUTO TRADING';
      }
    }
    $('autoAmountPanel')?.classList.toggle('enabled', selectedMode==='auto');
  }

  async function chooseMode(mode, button){
    if(!['paper','assisted','auto'].includes(mode) || controlBusy) return;
    const previous=selectedMode;
    selectedMode=mode;
    updateModeUI();
    try { await applyControl({mode}, `${button?.querySelector('b')?.textContent || modes[mode]} mode selected`); }
    catch { selectedMode=previous; updateModeUI(); }
  }

  async function applyAutoAmount(value, announce=true){
    if(controlBusy) return;
    const next=Math.max(5, Number(value)||5);
    const previous=autoTradeSize;
    autoTradeSize=next;
    if($('autoTradeInput')) $('autoTradeInput').value=next;
    if($('autoCustomTrade')) $('autoCustomTrade').value=next;
    safeText('autoAmountHeadline', `${shortMoney(next)} per automatic trade`);
    safeText('controlAmount', shortMoney(next));
    setPresetButtons(next);
    try {
      await applyControl({auto_trade_size:next}, announce?`Auto trade amount saved: ${money(next)}`:'');
      setSaveState(false);
    } catch {
      autoTradeSize=previous;
      if(appState) renderState(appState,{forceInputs:true});
    }
  }

  async function toggleBot(){
    if(controlBusy) return;
    if(selectedMode==='paper'){ go('trade'); toast('Manual Trade Desk opened'); return; }
    try {
      if(!appState) await refresh(true);
      const turnOn=!Boolean(appState?.bot_on);
      const result=await applyControl({
        mode:selectedMode,
        auto_trade_size:autoTradeSize,
        bot_on:turnOn
      }, '');
      if(result.control_blocked) return;
      if(turnOn && selectedMode==='auto' && result.positions.length>=result.settings.max_positions){
        toast(`AUTO ON • ${money(result.settings.auto_trade_size)}/trade • waiting for free slot`);
      } else {
        toast(turnOn ? (selectedMode==='auto'?`AUTO ON • ${money(result.settings.auto_trade_size)}/trade`:'AI scanner started') : 'Trading engine paused');
      }
    } catch { /* applyControl already reports */ }
  }

  function researchButtons(links={}){
    const a=(href,label)=>href?`<a class="research-link" href="${href}" target="_blank" rel="noopener">${label}</a>`:'';
    return a(links.dexscreener,'DEX')+a(links.pumpfun,'PF')+a(links.robinhood,'RH')+a(links.x,'𝕏');
  }

  function scannerItems(items=[]){
    const copy=[...items];
    if(scannerView==='score') return copy.sort((a,b)=>b.master_score-a.master_score);
    if(scannerView==='new') return copy.reverse();
    if(scannerView==='picks') return copy.filter(t=>t.decision==='BUY').concat(copy.filter(t=>t.decision!=='BUY'));
    return copy;
  }

  function tokenLogo(t){
    if(t?.image_url) return `<img src="${t.image_url}" alt="" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><span class="logo-fallback" style="display:none">●</span>`;
    return `<span class="logo-fallback">${t?.logo||'●'}</span>`;
  }

  function compactUsd(n){
    n=Number(n)||0;
    if(n>=1e9) return '$'+(n/1e9).toFixed(2)+'B';
    if(n>=1e6) return '$'+(n/1e6).toFixed(2)+'M';
    if(n>=1e3) return '$'+(n/1e3).toFixed(1)+'K';
    return money(n);
  }

  function priceText(n){
    n=Number(n)||0;
    if(n>=1) return '$'+n.toFixed(4);
    if(n>=.01) return '$'+n.toFixed(6);
    return '$'+n.toPrecision(5);
  }

  function ageText(mins){
    mins=Number(mins);
    if(!Number.isFinite(mins)) return 'unknown age';
    if(mins<60) return Math.round(mins)+'m';
    if(mins<1440) return (mins/60).toFixed(1)+'h';
    return (mins/1440).toFixed(1)+'d';
  }

  function renderScanner(items=[]){
    const root=$('scannerList'); if(!root) return;
    const visible=scannerItems(items);
    if(!visible.length){ root.innerHTML='<div class="token-card"><b>No live pairs available yet.</b><small>Master Trader will not invent replacement market data. Check Live Data Health and retry.</small></div>'; return; }
    root.innerHTML=visible.slice(0,12).map((t,i)=>`<article class="token-card live-token-card">
      <div class="token-top"><div class="rank">#${i+1}</div><div class="token-logo live-logo">${tokenLogo(t)}</div><div class="token-copy"><strong>${t.name} <span class="decision ${String(t.decision||'watch').toLowerCase()}">${t.decision}</span></strong><small>$${t.symbol} • ${t.launchpad} • ${ageText(t.pair_age_minutes)}</small></div><div class="ai-score"><b>${t.master_score}</b><small>AI SCORE</small></div></div>
      <div class="live-price-row"><strong>${priceText(t.price)}</strong><span class="${Number(t.price_change_m5)>=0?'positive':'negative'}">5m ${Number(t.price_change_m5)>=0?'+':''}${Number(t.price_change_m5||0).toFixed(1)}%</span><span>LIQ ${compactUsd(t.liquidity_usd)}</span><span>VOL 1H ${compactUsd(t.volume_h1)}</span></div>
      <div class="score-bar"><i style="width:${t.master_score}%"></i></div>
      <div class="token-badges"><span class="${t.decision==='BUY'?'buy':''}">Momentum ${t.momentum}</span><span>Flow ${t.activity}</span><span>Community ${t.community}</span><span>Safety ${t.safety}</span><span>Entry ${t.entry_quality}</span></div>
      <div class="flow-line"><span>5m buys <b>${t.buys_m5||0}</b></span><span>sells <b>${t.sells_m5||0}</b></span><span>buyers <b>${Number(t.buy_ratio_5m||0).toFixed(0)}%</b></span>${t.pump?.status?`<span>Pump <b>${t.pump.status}</b></span>`:''}</div>
      <div class="token-actions"><button type="button" data-ape-address="${t.token_address}" data-ape-amount="5">PAPER $5</button><button type="button" class="ape" data-ape-address="${t.token_address}" data-ape-amount="${Math.max(5,Number(appState?.settings?.manual_trade_size)||10)}">PAPER ${shortMoney(appState?.settings?.manual_trade_size||10)}</button><button type="button" class="chart-btn" data-chart-address="${t.token_address}">LIVE CHART</button>${researchButtons(t.links)}</div>
    </article>`).join('');
    const select=$('manualToken');
    if(select){
      const prior=select.value;
      select.innerHTML=visible.map(t=>`<option value="${t.token_address}">${t.name} ($${t.symbol}) — ${priceText(t.price)} — AI ${t.master_score}</option>`).join('');
      if([...select.options].some(o=>o.value===prior)) select.value=prior;
    }
    const chartSelect=$('liveChartToken');
    if(chartSelect){
      const prior=selectedChartAddress || chartSelect.value;
      chartSelect.innerHTML=visible.map(t=>`<option value="${t.token_address}">${t.name} ($${t.symbol})</option>`).join('');
      if([...chartSelect.options].some(o=>o.value===prior)) chartSelect.value=prior;
      selectedChartAddress=chartSelect.value || visible[0]?.token_address || null;
    }
  }

  function renderPortfolio(items=[]){
    const root=$('positionsList'); if(!root) return;
    if(!items.length){ root.innerHTML='<article class="holding-card"><div class="holding-info"><strong>No open paper positions</strong><small>Use Manual Trade or start Auto mode.</small></div></article>'; return; }
    root.innerHTML=items.map(p=>{
      const pnl=Number(p.current_value)-Number(p.cost_basis);
      const pct=pnl/Math.max(.000001,Number(p.cost_basis))*100;
      return `<article class="holding-card">
        <div class="holding-head"><div class="token-logo live-logo">${tokenLogo(p)}</div><div class="holding-info"><strong>${p.name}</strong><small>$${p.symbol} • ${p.chain} • ${p.source==='auto'?'AUTO':'MANUAL'}</small></div><div class="holding-pnl ${pnl>=0?'positive':'negative'}"><b>${pnl>=0?'+':''}${pct.toFixed(1)}%</b><small>${pnl>=0?'+':''}${money(pnl)}</small></div></div>
        <div class="holding-meta"><span>INVESTED<b>${money(p.cost_basis)}</b></span><span>VALUE<b>${money(p.current_value)}</b></span><span>LIVE PRICE<b>${priceText(p.current_price)}</b></span><span>AI SCORE<b>${p.master_score}/100</b></span></div>
        <div class="holding-footer"><div class="research-links">${researchButtons(p.links)}</div><div class="sell-links"><button type="button" data-sell-id="${p.id}" data-sell-percent="25">25%</button><button type="button" data-sell-id="${p.id}" data-sell-percent="50">50%</button><button type="button" data-sell-id="${p.id}" data-sell-percent="100">SELL ALL</button></div></div>
      </article>`;
    }).join('');
  }

  function renderAI(top){
    if(!top) return;
    safeText('quickToken', `${top.name} ($${top.symbol})`);
    safeText('quickScore', top.master_score);
    safeText('homeScore', top.master_score);
    if($('quickReasons')) $('quickReasons').innerHTML=`<span>Momentum ${top.momentum}</span><span>Flow ${top.activity}</span><span>Liquidity ${top.liquidity}</span><span>Safety ${top.safety}</span>`;
    safeText('aiWhyToken', `${top.name} • ${top.decision} • ${priceText(top.price)}`);
    const reasonText=(top.reasons||[]).slice(0,5);
    if($('aiWhyReasons')) $('aiWhyReasons').innerHTML=reasonText.map((r,i)=>`<div><i>${String(r).startsWith('RISK:')?'!':'✓'}</i><span><b>${['Market','Flow','Liquidity','Risk','Entry'][i]||'Signal'}</b><small>${r}</small></span></div>`).join('');
  }

  function updateChart(value){
    value=Number(value);
    if(!Number.isFinite(value)||value<=0) return;
    chartSeries.push(value);
    if(chartSeries.length>24) chartSeries.shift();
    const clean=chartSeries.map(Number).filter(Number.isFinite);
    if(clean.length<2) return;
    const min=Math.min(...clean), max=Math.max(...clean), span=Math.max(.01,max-min);
    const pts=clean.map((v,i)=>[i/(clean.length-1)*360,110-((v-min)/span)*88]);
    const d=pts.map((p,i)=>`${i?'L':'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
    try { $('chartLine')?.setAttribute('d',d); $('chartArea')?.setAttribute('d',`${d} L360,120 L0,120 Z`); }
    catch(err){ console.warn('Portfolio chart render skipped',err); }
  }

  function showBullEvent(level=5,token='MASTER TRADER',mult=level){
    safeText('eventEyebrow', level>=5?'BULL RUN JACKPOT':'BULL RUN MODE');
    safeText('eventTitle', level>=5?'MEGA WIN':'BULL RUN');
    safeText('eventValue', `${Number(mult).toFixed(1)}X TRADE`);
    safeText('eventToken', `$${token} • MOMENTUM UNLEASHED`);
    const el=$('bullEvent'); if(el){ el.classList.add('show'); el.setAttribute('aria-hidden','false'); }
  }

  function maybeBullEvent(s){
    let best=null;
    for(const p of s.positions||[]){
      const mult=Number(p.current_value)/Math.max(.000001,Number(p.cost_basis));
      if(!best||mult>best.mult) best={p,mult};
    }
    if(!best||best.mult<3) return;
    const level=best.mult>=5?5:3;
    const key=`${best.p.id}:${level}`;
    if(key===lastBullKey) return;
    lastBullKey=key;
    showBullEvent(level,best.p.symbol,best.mult);
  }

  function hydrateInputs(s){
    autoTradeSize=Number(s.settings.auto_trade_size)||10;
    setPresetButtons(autoTradeSize);
    safeText('autoAmountHeadline', `${shortMoney(autoTradeSize)} per automatic trade`);
    safeText('controlAmount', shortMoney(autoTradeSize));
    const values={autoTradeInput:autoTradeSize,manualTradeInput:s.settings.manual_trade_size,dailyTarget:s.settings.daily_target,dailyLoss:s.settings.daily_loss_limit,riskMode:s.settings.risk_mode,maxPositions:s.settings.max_positions,minScore:s.settings.min_score,takeProfit:s.settings.take_profit_pct,stopLoss:s.settings.stop_loss_pct,scanInterval:String(s.settings.scan_interval_seconds),autoScale:s.settings.auto_scale,dailyProfitStopLimit:s.settings.daily_profit_stop_limit,minLiquidity:s.settings.min_liquidity_usd,maxPortfolioHeat:s.settings.max_portfolio_heat_pct,entryCooldown:s.settings.entry_cooldown_seconds};
    Object.entries(values).forEach(([id,val])=>{ if($(id)) $(id).value=val; });
    if($('dailyProfitStopEnabled')) $('dailyProfitStopEnabled').checked=Boolean(s.settings.daily_profit_stop_enabled);
    if($('dailyProfitStopLimit')) $('dailyProfitStopLimit').disabled=!Boolean(s.settings.daily_profit_stop_enabled);
  }

  function renderWallet(w={}){
    const realized=Number(w.realized_pnl)||0, unrealized=Number(w.unrealized_pnl)||0;
    safeText('walletCashMini', money(w.available_cash));
    safeText('walletValueMini', money(w.portfolio_value));
    safeText('walletIdMini', w.wallet_id||'MT-PAPER');
    safeText('walletStatus', (w.status||'connected').toUpperCase()==='CONNECTED'?'PAPER CONNECTED':String(w.status||'PAPER'));
    safeText('walletId', w.wallet_id||'MT-PAPER');
    safeText('walletNetwork', w.network||'Solana live market / paper execution');
    safeText('walletAsset', w.settlement_asset||'Paper USDC');
    safeText('walletCash', money(w.available_cash));
    safeText('walletTotal', money(w.portfolio_value));
    safeText('walletDeployed', money(w.deployed_capital));
    safeText('walletPositions', w.open_positions??0);
    safeText('walletRealized', (realized>=0?'+':'')+money(realized));
    safeText('walletUnrealized', (unrealized>=0?'+':'')+money(unrealized));
    $('walletRealized')?.classList.toggle('negative',realized<0);
    $('walletUnrealized')?.classList.toggle('negative',unrealized<0);
  }

  function renderDataHealth(s){
    const m=s.market||{}, p=m.providers||{};
    const live=Boolean(s.market_fresh);
    safeText('marketHealthTitle', live?'LIVE SOLANA FEED HEALTHY':'DATA DEGRADED / STARTING');
    safeText('marketFreshPill', live?'LIVE':'PAUSED');
    $('marketFreshPill')?.classList.toggle('good',live);
    const status=(x)=>String(x?.configured===false?'OPTIONAL':x?.status||'unknown').toUpperCase();
    safeText('dexHealth',status(p.dexscreener)); safeText('geckoHealth',status(p.geckoterminal)); safeText('pumpHealth',status(p.pumpfun));
    safeText('heliusHealth',p.helius?.configured?status(p.helius):'OPTIONAL'); safeText('xHealth',p.x?.configured?status(p.x):'NOT CONNECTED');
    const age=m.last_good_market_at?Math.max(0,Math.round(Date.now()/1000-Number(m.last_good_market_at))):null;
    safeText('autoDataGate',m.auto_paused_reason || (live?`Live feed age ${age}s • Auto data gate open`:'Auto entries are fail-closed until live market data returns'));
  }

  function candleSvg(candles=[]){
    const svg=$('liveCandleChart'); if(!svg) return;
    svg.innerHTML='';
    if(!candles.length){ svg.innerHTML='<text x="20" y="130" fill="#8093a8" font-size="18">No live OHLCV returned for this pool.</text>'; return; }
    const rows=candles.slice(-48), lows=rows.map(c=>Number(c.l)), highs=rows.map(c=>Number(c.h));
    const lo=Math.min(...lows), hi=Math.max(...highs), span=Math.max(hi-lo,Math.abs(hi)*.0001,1e-12);
    const W=720,H=260,pad=14, step=(W-pad*2)/rows.length, body=Math.max(3,step*.55);
    const y=v=>pad+(hi-Number(v))/span*(H-pad*2);
    let html='';
    rows.forEach((c,i)=>{
      const x=pad+i*step+step/2, yo=y(c.o), yc=y(c.c), yh=y(c.h), yl=y(c.l), up=Number(c.c)>=Number(c.o);
      const cls=up?'candle-up':'candle-down', top=Math.min(yo,yc), h=Math.max(2,Math.abs(yc-yo));
      html+=`<line class="${cls}" x1="${x}" y1="${yh}" x2="${x}" y2="${yl}"/><rect class="${cls}" x="${x-body/2}" y="${top}" width="${body}" height="${h}" rx="1"/>`;
    });
    svg.innerHTML=html;
  }

  async function loadLiveChart(address=selectedChartAddress, timeframe=selectedTimeframe){
    if(!address) return;
    selectedChartAddress=address; selectedTimeframe=timeframe;
    const nonce=++chartLoadNonce;
    const token=(appState?.scanner||[]).find(t=>t.token_address===address);
    safeText('liveChartTitle', token?`${token.name} ($${token.symbol}) • ${priceText(token.price)}`:'Loading live chart…');
    safeText('liveChartMeta',`Loading ${timeframe} on-chain OHLCV…`);
    safeText('liveTradeStatus','Loading recent trades…');
    try{
      const [chart,trades]=await Promise.all([api(`/api/market/chart/${encodeURIComponent(address)}?timeframe=${encodeURIComponent(timeframe)}`),api(`/api/market/trades/${encodeURIComponent(address)}`)]);
      if(nonce!==chartLoadNonce) return;
      candleSvg(chart.candles||[]);
      safeText('liveChartMeta',`${chart.source} • ${timeframe} candles • ${(chart.candles||[]).length} intervals`);
      const root=$('liveTrades');
      const rows=trades.trades||[];
      if(root) root.innerHTML=rows.length?rows.slice(0,12).map(t=>`<div class="live-trade-row"><span class="${String(t.kind).toLowerCase().includes('buy')?'positive':'negative'}">${String(t.kind||'TRADE').toUpperCase()}</span><b>${compactUsd(t.volume_usd)}</b><small>${t.block_timestamp||''}</small></div>`).join(''):'<small>No recent trade rows returned.</small>';
      safeText('liveTradeStatus',`${rows.length} recent trades • ${trades.source}`);
    }catch(err){
      if(nonce!==chartLoadNonce) return;
      safeText('liveChartMeta','Live chart temporarily unavailable'); safeText('liveTradeStatus',err.message); candleSvg([]);
    }
  }

  async function searchMarket(){
    const q=$('marketSearchInput')?.value?.trim(); if(!q) return toast('Enter a token name or contract address',true);
    const root=$('marketSearchResults'); if(root) root.innerHTML='<small>Searching live Solana pairs…</small>';
    try{
      const data=await api(`/api/market/search?q=${encodeURIComponent(q)}`), rows=data.results||[];
      if(root) root.innerHTML=rows.length?rows.map(t=>`<div class="market-search-row"><div><b>${t.name} ($${t.symbol})</b><small>${t.token_address}</small></div><span>${priceText(t.price)} • ${compactUsd(t.liquidity_usd)} liq</span><button type="button" data-watch-address="${t.token_address}">LOAD</button></div>`).join(''):'<small>No Solana pairs found.</small>';
    }catch(err){ if(root) root.innerHTML=`<small>${err.message}</small>`; }
  }

  function renderState(s, opts={}){
    if(!acceptState(s, Boolean(opts.forceInputs))) return;
    appState=s;
    selectedMode=s.settings?.mode || selectedMode;
    if(!settingsDirty || opts.forceInputs) hydrateInputs(s);

    $('enginePill')?.classList.toggle('on',Boolean(s.bot_on));
    safeText('engineShort', s.bot_on?(s.settings.mode==='auto'?'AUTO ON':'AI ON'):'OFF');
    $('botDot')?.classList.toggle('on',Boolean(s.bot_on));
    safeText('botStatusText', s.bot_on?(selectedMode==='auto'?'AUTO TRADER LIVE':'AI SCANNER LIVE'):'AUTO TRADER OFF');
    safeText('engineStatus', s.status_message||'Paper engine ready');

    const pnl=Number(s.daily_pnl)||0, target=Number(s.settings.daily_target)||500, loss=Number(s.settings.daily_loss_limit)||250;
    safeText('dailyPnl',(pnl>=0?'+':'')+money(pnl));
    if($('dailyPnl')) $('dailyPnl').className=pnl<0?'negative':'';
    safeText('targetValue', money(target)); safeText('lossValue','-'+money(loss));
    if($('targetProgress')) $('targetProgress').style.width=clamp((Math.max(0,pnl)/target)*100,0,100)+'%';
    if($('lossProgress')) $('lossProgress').style.width=clamp((Math.max(0,-pnl)/loss)*100,0,100)+'%';
    safeText('pnlSub', pnl>=target?'TARGET ACHIEVED • AUTO CONTINUES':pnl>0?'GREEN DAY • TARGET IN SIGHT':'PAPER PERFORMANCE');
    safeText('controlTarget', money(target)); safeText('controlLoss','-'+money(loss));

    safeText('portfolioValue', money(s.portfolio_value)); safeText('portfolioValue2', money(s.portfolio_value));
    safeText('cashValue', money(s.cash)); safeText('cashValue2', money(s.cash)); safeText('deployedValue', money(s.deployed_capital));
    safeText('openCount',`${s.positions.length} / ${s.settings.max_positions}`); safeText('positionCount2',s.positions.length); safeText('historyCount',(s.history||[]).length);
    const up=Number(s.unrealized_pnl)||0; safeText('unrealizedPnl',(up>=0?'+':'')+money(up)); $('unrealizedPnl')?.classList.toggle('negative',up<0); $('unrealizedPnl')?.classList.toggle('positive',up>=0);
    safeText('scannedCount',(s.scanner||[]).length); safeText('approvedCount',s.approved_today||0); safeText('scoreMetric',s.risk_threshold);
    safeText('riskMetric',String(s.settings.risk_mode||'balanced').replace(/^./,c=>c.toUpperCase()));
    const perf=s.performance||{}; safeText('strategyVersion',s.strategy_version||'LIVE-1.3A'); safeText('perfWinRate',`${Number(perf.win_rate||0).toFixed(1)}%`); safeText('perfProfitFactor',Number(perf.profit_factor||0).toFixed(2)); safeText('perfExpectancy',money(perf.expectancy||0)); safeText('perfTrades',perf.closed_trades||0); safeText('perfAvgWin',money(perf.avg_win||0)); safeText('perfAvgLoss',money(perf.avg_loss||0));

    renderWallet(s.wallet||{}); renderDataHealth(s);
    renderScanner(s.scanner||[]); renderPortfolio(s.positions||[]); renderAI((s.scanner||[])[0]);
    updateModeUI(); updateChart(Number(s.portfolio_value)); maybeBullEvent(s);
  }

  function userIsEditing(){
    const a=document.activeElement;
    return Boolean(a && ['INPUT','SELECT','TEXTAREA'].includes(a.tagName));
  }

  async function refresh(force=false){
    if(!force && (controlBusy || settingsDirty || userIsEditing())) return;
    try {
      const s=await api('/api/state');
      renderState(s,{forceInputs:false});
    } catch(err){ safeText('engineStatus',err.message); }
  }

  async function manualBuy(tokenAddress,amount){
    amount=Math.max(5,Number(amount)||5);
    try {
      setBusy(true);
      await api('/api/trade/open',{method:'POST',body:JSON.stringify({token_address:tokenAddress,amount})});
      await refresh(true);
      const token=(appState?.scanner||[]).find(t=>t.token_address===tokenAddress);
      toast(`Live-market paper buy ${token?.symbol||''} for ${money(amount)}`);
      go('portfolio');
    } catch(err){ toast(err.message,true); }
    finally { setBusy(false); }
  }

  async function sellPosition(id,percent){
    try {
      setBusy(true);
      await api('/api/trade/close',{method:'POST',body:JSON.stringify({position_id:Number(id),percent:Number(percent)})});
      await refresh(true);
      toast(`Paper sell ${percent}% complete`);
    } catch(err){ toast(err.message,true); }
    finally { setBusy(false); }
  }

  async function copyWallet(){
    const value=$('walletId')?.textContent || appState?.wallet?.wallet_id || 'MT-PAPER';
    try {
      if(navigator.clipboard?.writeText) await navigator.clipboard.writeText(value);
      else {
        const ta=document.createElement('textarea'); ta.value=value; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
      }
      toast('Wallet ID copied');
    } catch { toast('Copy unavailable — press and hold the Wallet ID',true); }
  }

  function bindEvents(){
    document.addEventListener('click', async e => {
      const nav=e.target.closest('[data-nav]'); if(nav){ go(nav.dataset.nav); return; }
      const goBtn=e.target.closest('[data-go]'); if(goBtn){ go(goBtn.dataset.go); return; }
      const modeBtn=e.target.closest('[data-mode]'); if(modeBtn){ await chooseMode(modeBtn.dataset.mode, modeBtn); return; }
      const autoPreset=e.target.closest('#autoPresetRow [data-value]');
      if(autoPreset){
        if(autoPreset.dataset.value==='custom'){
          $('autoCustomRow')?.classList.remove('hidden'); $('autoCustomTrade')?.focus();
        } else await applyAutoAmount(Number(autoPreset.dataset.value));
        return;
      }
      const manualPreset=e.target.closest('#manualPresets [data-value]');
      if(manualPreset){
        const amount=Number(manualPreset.dataset.value); if($('manualTradeInput')) $('manualTradeInput').value=amount;
        markSettingsDirty(); try{ await persistSettings(true); toast(`Manual trade amount set to ${money(amount)}`); }catch{}
        return;
      }
      const ape=e.target.closest('[data-ape-address]'); if(ape){ await manualBuy(ape.dataset.apeAddress,ape.dataset.apeAmount); return; }
      const chartBtn=e.target.closest('[data-chart-address]'); if(chartBtn){ go('scan'); selectedChartAddress=chartBtn.dataset.chartAddress; if($('liveChartToken')) $('liveChartToken').value=selectedChartAddress; await loadLiveChart(selectedChartAddress,selectedTimeframe); return; }
      const watch=e.target.closest('[data-watch-address]'); if(watch){ try{setBusy(true);const st=await api(`/api/market/watch/${encodeURIComponent(watch.dataset.watchAddress)}`,{method:'POST'});renderState(st,{forceInputs:false});selectedChartAddress=watch.dataset.watchAddress;go('scan');await loadLiveChart(selectedChartAddress,selectedTimeframe);toast('Live token loaded');}catch(err){toast(err.message,true)}finally{setBusy(false)} return; }
      const sell=e.target.closest('[data-sell-id]'); if(sell){ await sellPosition(sell.dataset.sellId,sell.dataset.sellPercent); return; }
    });

    $('applyAutoCustom')?.addEventListener('click',()=>applyAutoAmount($('autoCustomTrade')?.value));
    $('autoCustomTrade')?.addEventListener('input',()=>{
      autoTradeSize=Math.max(5,Number($('autoCustomTrade').value)||5); if($('autoTradeInput')) $('autoTradeInput').value=autoTradeSize;
      safeText('autoAmountHeadline',`${shortMoney(autoTradeSize)} per automatic trade`); safeText('controlAmount',shortMoney(autoTradeSize)); markSettingsDirty();
    });
    $('autoTradeInput')?.addEventListener('input',()=>{
      autoTradeSize=Math.max(5,Number($('autoTradeInput').value)||5); setPresetButtons(autoTradeSize);
      safeText('autoAmountHeadline',`${shortMoney(autoTradeSize)} per automatic trade`); safeText('controlAmount',shortMoney(autoTradeSize)); markSettingsDirty();
    });

    const settingsControls=['dailyTarget','dailyLoss','dailyProfitStopEnabled','dailyProfitStopLimit','riskMode','maxPositions','minScore','takeProfit','stopLoss','scanInterval','autoScale','minLiquidity','maxPortfolioHeat','entryCooldown'];
    settingsControls.forEach(id=>{ const el=$(id); if(el){ el.addEventListener('input',markSettingsDirty); el.addEventListener('change',markSettingsDirty); } });
    $('dailyProfitStopEnabled')?.addEventListener('change',()=>{ if($('dailyProfitStopLimit')) $('dailyProfitStopLimit').disabled=!$('dailyProfitStopEnabled').checked; });
    $('manualTradeInput')?.addEventListener('change',async()=>{ markSettingsDirty(); try{await persistSettings(true);}catch{} });

    $('botToggle')?.addEventListener('click',toggleBot);
    $('scanBtn')?.addEventListener('click',async()=>{ try{ setBusy(true); await api('/api/scan',{method:'POST'}); await refresh(true); toast('Fresh scan complete'); }catch(err){toast(err.message,true)}finally{setBusy(false)} });
    $('saveSettings')?.addEventListener('click',()=>persistSettings(false));
    $('resetBtn')?.addEventListener('click',async()=>{
      if(!confirm('Reset the paper portfolio and trade history? Your bot settings will be kept.')) return;
      try{ setBusy(true); setSaveState(false); const s=await api('/api/reset/portfolio',{method:'POST'}); renderState(s,{forceInputs:true}); toast('Paper portfolio reset'); }catch(err){toast('Reset failed: '+err.message,true)}finally{setBusy(false)}
    });
    $('resetSettingsBtn')?.addEventListener('click',async()=>{
      if(!confirm('Reset all bot configuration values to defaults?')) return;
      try{ setBusy(true); setSaveState(false); const s=await api('/api/reset/settings',{method:'POST'}); renderState(s,{forceInputs:true}); toast('Bot settings reset to defaults'); }catch(err){toast('Settings reset failed: '+err.message,true)}finally{setBusy(false)}
    });
    $('manualBuy')?.addEventListener('click',()=>{ const address=$('manualToken')?.value; if(!address)return toast('Select a token first',true); manualBuy(address,$('manualTradeInput')?.value); });
    $('copyWalletId')?.addEventListener('click',copyWallet);
    $('marketSearchBtn')?.addEventListener('click',searchMarket);
    $('marketSearchInput')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();searchMarket();}});
    $('liveChartToken')?.addEventListener('change',e=>loadLiveChart(e.target.value,selectedTimeframe));
    document.querySelectorAll('#timeframeRow [data-tf]').forEach(b=>b.addEventListener('click',async()=>{selectedTimeframe=b.dataset.tf;document.querySelectorAll('#timeframeRow [data-tf]').forEach(x=>x.classList.toggle('active',x===b));await loadLiveChart(selectedChartAddress,selectedTimeframe);}));

    document.querySelectorAll('.filter-row button').forEach((b,i)=>b.addEventListener('click',()=>{
      scannerView=['trending','score','new','picks'][i]||'trending';
      document.querySelectorAll('.filter-row button').forEach(x=>x.classList.toggle('active',x===b)); renderScanner(appState?.scanner||[]);
    }));

    $('previewBull')?.addEventListener('click',()=>showBullEvent(5,'PREVIEW',5));
    $('closeBullEvent')?.addEventListener('click',()=>{ $('bullEvent')?.classList.remove('show'); $('bullEvent')?.setAttribute('aria-hidden','true'); });
    $('homeHelp')?.addEventListener('click',()=>$('helpModal')?.classList.remove('hidden'));
    $('menuBtn')?.addEventListener('click',()=>$('helpModal')?.classList.remove('hidden'));
    $('closeHelp')?.addEventListener('click',()=>$('helpModal')?.classList.add('hidden'));
    $('helpModal')?.addEventListener('click',e=>{ if(e.target===$('helpModal')) $('helpModal').classList.add('hidden'); });
  }

  window.addEventListener('unhandledrejection',e=>{ console.error('Unhandled promise rejection',e.reason); toast('A control request failed. Please try again.',true); });
  window.addEventListener('error',e=>{ console.error('UI error',e.error||e.message); });

  function start(){
    bindEvents(); setSaveState(false); rotateBull(); setInterval(rotateBull,7000); refresh(true);
    refreshTimer=setInterval(()=>refresh(false),3000);
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start); else start();
})();
